| Image | Name |
| ----- | ---- |
| ![](creatures/GuardianCharacter.png) | The Guardian |
| ![](creatures/SlimeboundCharacter.png) | The Slime Boss |
| ![](creatures/AutomatonChar.png) | the Automaton |
| ![](creatures/ChampChar.png) | the Champ |
| ![](creatures/TheHexaghost.png) | the Hexaghost |
| ![](creatures/TheSnecko.png) | the Snecko |
| ![](creatures/Augmenter.png) | Augmenter |
| ![](creatures/BlackKnight.png) | Black Knight |
| ![](creatures/FaceTrader.png) | Face Trader |
| ![](creatures/ForgetfulTotem.png) | Forgetful Head |
| ![](creatures/ChangingTotem.png) | Head of Change |
| ![](creatures/GrowingTotem.png) | Head of Growth |
| ![](creatures/LooterAlt.png) | Looter |
| ![](creatures/MuggerAlt.png) | Looter |
| ![](creatures/FleeingMerchant.png) | Merchant |
| ![](creatures/CharBossMerchant.png) | Merchant |
| ![](creatures/NeowBoss.png) | Neow |
| ![](creatures/NeowBossFinal.png) | Neow |
| ![](creatures/Defect.png) | The Defect |
| ![](creatures/Ironclad.png) | The Ironclad |
| ![](creatures/Silent.png) | The Silent |
| ![](creatures/Watcher.png) | The Watcher |
| ![](creatures/LadyInBlue.png) | The Woman in Blue |
