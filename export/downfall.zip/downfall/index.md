
## Cards

| Name | Image | Upgraded image | Rarity | Type | Cost | Description |
| ---- | ----- | -------------- | ------ | ---- | ---- | ----------- |
| Batch | ![](small-card-images/Batch.png) | ![](small-card-images/BatchPlus.png) | Special | Skill | 0 | Create a Function immediately out of the cards in the Sequence. Exhaust. (not Exhaust.) |
| Beta Build | ![](small-card-images/BetaBuild.png) | ![](small-card-images/BetaBuildPlus.png) | Special | Skill | 2 | Gain 15(20) Block. bronze:Insert random Status. bronze:Compile - bronze:Insert *Full *Release. |
| Branch: Attack | ![](small-card-images/Branch-Attack.png) | ![](small-card-images/Branch-AttackPlus.png) | Special | Attack | 1 | Deal 9(11) damage. |
| Branch: Block | ![](small-card-images/Branch-Block.png) | ![](small-card-images/Branch-BlockPlus.png) | Special | Skill | 1 | Gain 8(10) Block. |
| Byte Shift | ![](small-card-images/ByteShift.png) | ![](small-card-images/ByteShiftPlus.png) | Special | Skill | 0 | (Retain.)  Return all cards in the Sequence to your hand. They gain Retain. Exhaust. |
| Council's Justice | ![](small-card-images/CouncilsJustice.png) | ![](small-card-images/CouncilsJusticePlus.png) | Special | Attack | 1 | Ethereal. Deal 6(10) damage. Damage is increased by 3(4) for each *Apparition in your exhaust pile. Exhaust. |
| Dazing Pulse | ![](small-card-images/DazingPulse.png) | ![](small-card-images/DazingPulsePlus.png) | Special | Attack | 1 | Deal 5(7) damage. Gain 5(7) Block bronze:Compile *Error - bronze:Insert 2 *Dazed. |
| Debug | ![](small-card-images/Debug.png) | ![](small-card-images/DebugPlus.png) | Special | Skill | 0 | Remove all bronze:Compile *Error effects from the cards in the Sequence. Exhaust. |
| Decompile | ![](small-card-images/Decompile.png) | ![](small-card-images/DecompilePlus.png) | Special | Skill | 0 | (Retain.)  Exhaust all cards in the Sequence. Gain [E] and draw a card for each card Exhausted. Exhaust. |
| Explode | ![](small-card-images/Explode.png) | ![](small-card-images/ExplodePlus.png) | Special | Skill | 1 | bronze:Insert a *Burn. bronze:Compile - ALL enemies lose 15(20) HP. |
| Finishing Strike | ![](small-card-images/FinishingStrike.png) | ![](small-card-images/FinishingStrikePlus.png) | Special | Attack | 1 | Retain. Deal 6(9) damage. [fist_icon]   champ:Finisher |
| Fragment | ![](small-card-images/Fragment.png) | ![](small-card-images/FragmentPlus.png) | Special | Attack | 1 | Deal 6(8) damage. Gain 6(8) Block. |
| Full Release | ![](small-card-images/FullRelease.png) | ![](small-card-images/FullReleasePlus.png) | Special | Skill | 3(0) | bronze:Compile - Function becomes a Power which activates its effects at the start of each turn. |
| Knowing Skull | ![](small-card-images/KnowingSkull.png) | ![](small-card-images/KnowingSkullPlus.png) | Special | Skill | 0 | Ethereal. Spend HP to Wish for Souls, Success, or a Pick Me Up. Exhaust. |
| Lick | ![](small-card-images/Lick.png) | ![](small-card-images/LickPlus.png) | Special | Skill | 0 | Apply !SlimeboundSlimed! slimeboundmod:Goop. Exhaust. |
| Minor Beam | ![](small-card-images/MinorBeam.png) | ![](small-card-images/MinorBeamPlus.png) | Special | Attack | 0 | Deal 3(4) damage. |
| Orb Slam | ![](small-card-images/OrbSlam.png) | ![](small-card-images/OrbSlamPlus.png) | Special | Attack | 0 | Deal 2(3) damage !GuardianMulti! times. Exhaust. |
| Package: Ancients | ![](small-card-images/Package-Ancients.png) | ![](small-card-images/Package-AncientsPlus.png) | Special | Skill | 0 | Add an *Ancient *Attack, *Ancient *Power, and *Ancient *Construct to your hand (and Upgrade them). Exhaust. |
| Package: Bronze | ![](small-card-images/Package-Bronze.png) | ![](small-card-images/Package-BronzePlus.png) | Special | Skill | 0 | Add a *Hyper *Beam, *Orb *Beam, and *Bronze *Armor to your hand (and Upgrade them). Exhaust. |
| Package: Defect | ![](small-card-images/Package-Defect.png) | ![](small-card-images/Package-DefectPlus.png) | Special | Skill | 0 | Add a *Reroute, *Preprogram, and *Time *Capacitor to your hand (and Upgrade them). Exhaust. |
| Package: Orbwalker | ![](small-card-images/Package-Orbwalker.png) | ![](small-card-images/Package-OrbwalkerPlus.png) | Special | Skill | 0 | Add an *Orbwalk, *Walker *Claw, and *Incinerate to your hand (and Upgrade them). Exhaust. |
| Package: Sentry | ![](small-card-images/Package-Sentry.png) | ![](small-card-images/Package-SentryPlus.png) | Special | Skill | 0 | Add a *Sentry *Blast (*Blast+) and two *Sentry *Waves (*Waves+) to your hand and reduce their costs by 1 this combat. Exhaust. |
| Package: Shapes | ![](small-card-images/Package-Shapes.png) | ![](small-card-images/Package-ShapesPlus.png) | Special | Skill | 0 | Add a *Time *Bomb, *Spiker *Protocol, and *Repulsor to your hand (and Upgrade them). Exhaust. |
| Package: Spheric | ![](small-card-images/Package-Spheric.png) | ![](small-card-images/Package-SphericPlus.png) | Special | Skill | 0 | Add a *Spheric *Shield, *Harden, and *Floating *Orbs to your hand (and Upgrade them). Exhaust. |
| Proto-Beam | ![](small-card-images/Proto-Beam.png) | ![](small-card-images/Proto-BeamPlus.png) | Special | Attack | 2 | Deal 8 damage 2(3) times. bronze:Compile - Gain 2(3) Strength and lose !bauto! Dexterity. |
| Proto-Shield | ![](small-card-images/Proto-Shield.png) | ![](small-card-images/Proto-ShieldPlus.png) | Special | Skill | 2 | Gain 16 Block. bronze:Compile - Gain 4(6) Plated Armor and bronze:Insert !bauto! *Dazed. |
| SLIME CRUSH!!! | ![](small-card-images/SLIMECRUSH!!!.png) | ![](small-card-images/SLIMECRUSH!!!Plus.png) | Special | Attack | 4 | Ethereal. Deal 35(45) damage. Exhaust. |
| Sentry Wave | ![](small-card-images/SentryWave.png) | ![](small-card-images/SentryWavePlus.png) | Special | Skill | 0 | Apply 1 Weak. (guardianmod:Brace 2.)  Place a *Sentry *Blast (*Blast+) into guardianmod:Stasis. Exhaust. |
| Shadow Guise | ![](small-card-images/ShadowGuise.png) | ![](small-card-images/ShadowGuisePlus.png) | Special | Skill | 1 | Gain 14(18) Block. Exhaust. |
| Shadow Strike | ![](small-card-images/ShadowStrike.png) | ![](small-card-images/ShadowStrikePlus.png) | Special | Attack | 1 | Deal 16(20) damage. Exhaust. |
| Spike | ![](small-card-images/Spike.png) | ![](small-card-images/SpikePlus.png) | Special | Attack | 1 | Deal 3(4) damage. bronze:Compile - Gain 3(4) Thorns. |
| Aged | ![](small-card-images/Aged.png) | ![]() | Curse | Curse |  | Unplayable. Ethereal. At the end of your turn, add a Void Status to the top of your draw pile. |
| Bewildered | ![](small-card-images/Bewildered.png) | ![]() | Curse | Curse | 2 | When you play another card, sneckomod:Muddle your hand, then discard this. Exhaust. |
| Flawed | ![](small-card-images/Flawed.png) | ![]() | Curse | Curse | 1 | Ethereal. At the end of your turn, transform all cards in hand into random Status cards. Exhaust. |
| Haunted | ![](small-card-images/Haunted.png) | ![]() | Curse | Curse |  | Ethereal. Unplayable. When drawn, add Ethereal to all cards in your hand. |
| Icky | ![](small-card-images/Icky.png) | ![]() | Curse | Curse | 1 | Add a Slimed Status to your hand. Exhaust. |
| Deca Shield | ![](small-card-images/DecaShield.png) | ![](small-card-images/DecaShieldPlus.png) | Special | Skill | 2 | Ethereal. expansioncontent:Boss - Ancients. Gain 14(18) Block. Next turn, add a *Donu *Blast (*Blast+) with Ethereal into your hand. Exhaust. |
| Automa-Beam | ![](small-card-images/Automa-Beam.png) | ![](small-card-images/Automa-BeamPlus.png) | Uncommon | Attack | 2 | expansioncontent:Boss - Automaton. Deal 26(34) damage to ALL enemies. At the start of your next turn, lose [E]. Exhaust. |
| Awaken | ![](small-card-images/Awaken.png) | ![](small-card-images/AwakenPlus.png) | Uncommon | Power | 2 | expansioncontent:Boss - Awakened One. Gain 1 Strength. When you would die, heal 20(30) HP instead. |
| Chrono-Boost | ![](small-card-images/Chrono-Boost.png) | ![](small-card-images/Chrono-BoostPlus.png) | Uncommon | Power | 2 | expansioncontent:Boss - Time Eater. Gain 1 Strength (. Gain 1 Strength) for every 12th card you play. |
| Donu Blast | ![](small-card-images/DonuBlast.png) | ![](small-card-images/DonuBlastPlus.png) | Uncommon | Attack | 2 | expansioncontent:Boss - Ancients. Deal 9(12) damage twice. Next turn, add a *Deca *Shield (*Shield+) into your hand. Exhaust. |
| Guardian Whirl | ![](small-card-images/GuardianWhirl.png) | ![](small-card-images/GuardianWhirlPlus.png) | Uncommon | Attack | 2 | expansioncontent:Boss - Guardian. Requires 10 or more Block. Deal 4(6) damage to ALL enemies 4 times. Exhaust. |
| Hexaburn | ![](small-card-images/Hexaburn.png) | ![](small-card-images/HexaburnPlus.png) | Uncommon | Power | 2 | expansioncontent:Boss - Hexaghost. In 6(4) turns, deal 6 damage to a random enemy 6 times. |
| Invincible | ![](small-card-images/Invincible.png) | ![](small-card-images/InvinciblePlus.png) | Uncommon | Power | 2(1) | expansioncontent:Boss - Corrupt Heart. Gain 10 expansioncontent:Invincible. If you already had expansioncontent:Invincible, it lasts another turn instead. |
| Last Stand | ![](small-card-images/LastStand.png) | ![](small-card-images/LastStandPlus.png) | Uncommon | Power | 2 | expansioncontent:Boss - Champ. Remove all Debuffs. Gain 1 Strength. If you are below half HP, Gain (Heal 10 and gain) 2 Strength. |
| Prepare Crush | ![](small-card-images/PrepareCrush.png) | ![](small-card-images/PrepareCrushPlus.png) | Uncommon | Skill | 2 | expansioncontent:Boss - Slime. Gain 10(15) Block. On your next turn, gain [E] [E] [E] and add SLIME CRUSH to your hand. Exhaust. |
| YOU ARE MINE! | ![](small-card-images/YOUAREMINE!.png) | ![](small-card-images/YOUAREMINE!Plus.png) | Uncommon | Skill | 2 | expansioncontent:Boss - Collector. Remove ALL enemy Block. Apply 3(5) Weak and Vulnerable to ALL enemies. Exhaust. |
| Quick Study | ![](small-card-images/QuickStudy.png) | ![](small-card-images/QuickStudyPlus.png) | Rare | Skill | 1 | Choose 1 of 3 (Upgraded) expansioncontent:Boss cards. Add it into your hand. It costs 0 until played. Exhaust. |
| Study the Spire | ![](small-card-images/StudytheSpire.png) | ![](small-card-images/StudytheSpirePlus.png) | Rare | Power | 3 | Add a random (Upgraded) expansioncontent:Boss card to your hand at the start of your next 3 turns. They cost 0 until played. |
| The Evil Within | ![](small-card-images/TheEvilWithin.png) | ![](small-card-images/TheEvilWithinPlus.png) | Rare | Attack | 2 | Deal 10(12) damage. Gain 10(12) Block. Add a random (Upgraded) expansioncontent:Boss card to your hand. It costs 0 until played. Exhaust. |
| Defend | ![](small-card-images/Defend.png) | ![](small-card-images/DefendPlus.png) | Basic | Skill | 1 | Gain 5(8) Block. |
| Float | ![](small-card-images/Float.png) | ![](small-card-images/FloatPlus.png) | Basic | Skill | 0 | Ethereal. Draw a card. (You may choose to hexamod:Retract or) hexamod:Advance. |
| Sear | ![](small-card-images/Sear.png) | ![](small-card-images/SearPlus.png) | Basic | Skill | 1 | Apply !burny! hexamod:Soulburn. |
| Strike | ![](small-card-images/Strike.png) | ![](small-card-images/StrikePlus.png) | Basic | Attack | 1 | Deal 6(9) damage. |
| Advancing Guard | ![](small-card-images/AdvancingGuard.png) | ![](small-card-images/AdvancingGuardPlus.png) | Common | Skill | 1 | Gain 8(11) Block. hexamod:Advance. |
| Backtrack Smack | ![](small-card-images/BacktrackSmack.png) | ![](small-card-images/BacktrackSmackPlus.png) | Common | Attack | 1 | Deal 12(15) damage. hexamod:Retract. |
| Burning Touch | ![](small-card-images/BurningTouch.png) | ![](small-card-images/BurningTouchPlus.png) | Common | Skill | 1 | If the enemy has hexamod:Soulburn, apply !burny! hexamod:Soulburn. Apply !burny! hexamod:Soulburn. |
| Fast Forward | ![](small-card-images/FastForward.png) | ![](small-card-images/FastForwardPlus.png) | Common | Skill | 1 | Ethereal. (not Ethereal.) hexamod:Force-Ignite the hexamod:Active Ghostflame. hexamod:Advance. |
| Firestarter | ![](small-card-images/Firestarter.png) | ![](small-card-images/FirestarterPlus.png) | Common | Attack | 1 | Deal 5(7) damage. Apply !burny! hexamod:Soulburn. |
| Flames from Beyond | ![](small-card-images/FlamesfromBeyond.png) | ![](small-card-images/FlamesfromBeyondPlus.png) | Common | Skill |  | Unplayable. Ethereal, hexamod:Afterlife. Apply !burny! hexamod:Soulburn to ALL enemies. |
| Ghost Lash | ![](small-card-images/GhostLash.png) | ![](small-card-images/GhostLashPlus.png) | Common | Attack | 1 | Ethereal. Deal 8(11) damage. If your hand contains another Ethereal card, deal 8(11) damage. |
| Ghost Shield | ![](small-card-images/GhostShield.png) | ![](small-card-images/GhostShieldPlus.png) | Common | Skill | 1 | Ethereal. Gain 6(8) Block. If your hand contains another Ethereal card, gain 6(8) Block. |
| Haunting Echo | ![](small-card-images/HauntingEcho.png) | ![](small-card-images/HauntingEchoPlus.png) | Common | Attack | 1 | Deal 8(11) damage. If the hexamod:Active Ghostflame is hexamod:Ignited, hexamod:Force-Ignite it. |
| Heat Metal | ![](small-card-images/HeatMetal.png) | ![](small-card-images/HeatMetalPlus.png) | Common | Attack | 1 | Deal 8(10) damage. After hexamod:Soulburn detonates on this enemy, apply 12(18) hexamod:Soulburn. |
| Hexaguard | ![](small-card-images/Hexaguard.png) | ![](small-card-images/HexaguardPlus.png) | Common | Skill | 1 | Ethereal. hexamod:Afterlife. Gain 7(10) Block. Draw 1 card. |
| Nightmare Guise | ![](small-card-images/NightmareGuise.png) | ![](small-card-images/NightmareGuisePlus.png) | Common | Skill | 2 | Ethereal. Gain 14(18) Block. If this card is Exhausted, add a *Shadow *Guise into (*Guise+ to) your hand. |
| Nightmare Strike | ![](small-card-images/NightmareStrike.png) | ![](small-card-images/NightmareStrikePlus.png) | Common | Attack | 2 | Ethereal. Deal 16(20) damage. If this card is Exhausted, add a *Shadow *Strike into (*Strike+ to) your hand. |
| Searing Strike | ![](small-card-images/SearingStrike.png) | ![](small-card-images/SearingStrikePlus.png) | Common | Attack | 1 | Ethereal. Deal 10(14) damage. Apply !burny! hexamod:Soulburn. If this card is Exhausted, take 6 damage. |
| Shield of Night | ![](small-card-images/ShieldofNight.png) | ![](small-card-images/ShieldofNightPlus.png) | Common | Skill | 2 | If the hexamod:Active Ghostflame is not hexamod:Ignited, gain [E] . Gain 12(16) Block. |
| Specter's Wail | ![](small-card-images/SpectersWail.png) | ![](small-card-images/SpectersWailPlus.png) | Common | Attack | 1 | Ethereal. hexamod:Afterlife. Deal 8(11) damage to ALL enemies. |
| Stoke the Fire | ![](small-card-images/StoketheFire.png) | ![](small-card-images/StoketheFirePlus.png) | Common | Skill | 1 | Gain 5(8) Block. For each hexamod:Ignited Ghostflame, Upgrade a random card in your hand. |
| Sword of Night | ![](small-card-images/SwordofNight.png) | ![](small-card-images/SwordofNightPlus.png) | Common | Attack | 2 | If the hexamod:Active Ghostflame is not hexamod:Ignited, gain [E] . Deal 14(18) damage. |
| Thermal Transfer | ![](small-card-images/ThermalTransfer.png) | ![](small-card-images/ThermalTransferPlus.png) | Common | Attack | 1 | Deal 7(10) damage. If the enemy has hexamod:Soulburn, gain 5(8) Block. |
| Again! | ![](small-card-images/Again!.png) | ![](small-card-images/Again!Plus.png) | Uncommon | Skill | 1(0) | hexamod:Force-Ignite the hexamod:Active Ghostflame. Do not hexamod:Advance at the end of this turn. |
| Bright Ritual | ![](small-card-images/BrightRitual.png) | ![](small-card-images/BrightRitualPlus.png) | Uncommon | Skill | 1(0) | Gain [E] and draw 1 card for each for each hexamod:Ignited Ghostflame, then hexamod:Extinguish them. Exhaust. |
| Catch Up | ![](small-card-images/CatchUp.png) | ![](small-card-images/CatchUpPlus.png) | Uncommon | Skill | 1(0) | hexamod:Force-Ignite the previous Ghostflame. |
| Charged Barrage | ![](small-card-images/ChargedBarrage.png) | ![](small-card-images/ChargedBarragePlus.png) | Uncommon | Skill | 1 | Apply !burny! hexamod:Soulburn. Repeat for each hexamod:Ignited Ghostflame. |
| Devil's Dance | ![](small-card-images/DevilsDance.png) | ![](small-card-images/DevilsDancePlus.png) | Uncommon | Power | 1 | (Innate.)  The first time you hexamod:Retract each turn, gain [E] and draw 1 card. hexamod:Retract. |
| Dynamic Blow | ![](small-card-images/DynamicBlow.png) | ![](small-card-images/DynamicBlowPlus.png) | Uncommon | Attack | 1 | Ethereal. If the hexamod:Active Ghostflame is hexamod:Ignited, apply !burny! hexamod:Soulburn. If not, deal 10(13) damage. |
| Eerie Expedition | ![](small-card-images/EerieExpedition.png) | ![](small-card-images/EerieExpeditionPlus.png) | Uncommon | Skill | 1(0) | Ethereal. Add a random Ethereal card into your hand. It costs 0 this turn. Exhaust. |
| Empowered Flame | ![](small-card-images/EmpoweredFlame.png) | ![](small-card-images/EmpoweredFlamePlus.png) | Uncommon | Power | 1 | Gain 2(3) hexamod:Intensity. |
| Extra Crispy | ![](small-card-images/ExtraCrispy.png) | ![](small-card-images/ExtraCrispyPlus.png) | Uncommon | Power | 1 | (Innate.)  Cards and Ghostflames apply 2 more hexamod:Soulburn. |
| First Seal | ![](small-card-images/FirstSeal.png) | ![]() | Uncommon | Power | 1 | Ethereal hexamod:Seal. At the end of combat, heal 7 HP. |
| Fourth Seal | ![](small-card-images/FourthSeal.png) | ![]() | Uncommon | Power | 1 | Ethereal hexamod:Seal. At the end of combat, gain an additional Potion reward. |
| Ghostflame Wall | ![](small-card-images/GhostflameWall.png) | ![](small-card-images/GhostflameWallPlus.png) | Uncommon | Skill | 2 | Gain 12(16) Block. Whenever you are attacked this turn, apply -1 hexamod:Soulburn to the attacker. |
| Haunted Hand | ![](small-card-images/HauntedHand.png) | ![](small-card-images/HauntedHandPlus.png) | Uncommon | Skill | 0 | Ethereal. Draw 2(3) cards. All cards in your hand become Ethereal. Exhaust. |
| Heat Crush | ![](small-card-images/HeatCrush.png) | ![](small-card-images/HeatCrushPlus.png) | Uncommon | Attack | 3 | Deal 20(30) damage. Damage is increased by enemy's hexamod:Soulburn. |
| Heat Shield | ![](small-card-images/HeatShield.png) | ![](small-card-images/HeatShieldPlus.png) | Uncommon | Skill | 2 | Ethereal. (not Ethereal.) Gain 5 Block, increased by hexamod:Soulburn on ALL enemies. |
| Incineration | ![](small-card-images/Incineration.png) | ![](small-card-images/IncinerationPlus.png) | Uncommon | Attack | 2 | Deal 4 damage and apply !burny! hexamod:Soulburn to a random enemy 3(4) times. |
| Incorporeal | ![](small-card-images/Incorporeal.png) | ![](small-card-images/IncorporealPlus.png) | Uncommon | Skill | 0 | hexamod:Retract. Lose 6(3) HP. Gain 1 Intangible. Exhaust. |
| Living Bomb | ![](small-card-images/LivingBomb.png) | ![](small-card-images/LivingBombPlus.png) | Uncommon | Skill | 0 | Apply !burny! hexamod:Soulburn. The next time the target's hexamod:Soulburn detonates, it affects ALL enemies. Exhaust. (not Exhaust.) |
| Nightmare Vision | ![](small-card-images/NightmareVision.png) | ![](small-card-images/NightmareVisionPlus.png) | Uncommon | Skill | 0 | Put an (2) Ethereal card(s) from your exhaust pile into your hand. Exhaust. |
| Phantom Cloak | ![](small-card-images/PhantomCloak.png) | ![](small-card-images/PhantomCloakPlus.png) | Uncommon | Power | 1 | Ethereal. Gain 2(3) Dexterity and lose 1 Strength. |
| Phantom Fireball | ![](small-card-images/PhantomFireball.png) | ![](small-card-images/PhantomFireballPlus.png) | Uncommon | Attack | 1 | Deal 8(11) damage. If the enemy has hexamod:Soulburn, detonate it. |
| Power from Beyond | ![](small-card-images/PowerfromBeyond.png) | ![](small-card-images/PowerfromBeyondPlus.png) | Uncommon | Skill |  | Unplayable. Ethereal. hexamod:Afterlife. Gain [E] and draw 1(2) card(s) next turn. |
| Radiant Flame | ![](small-card-images/RadiantFlame.png) | ![](small-card-images/RadiantFlamePlus.png) | Uncommon | Power | 1 | Whenever you hexamod:Ignite a Ghostflame, apply 3(5) hexamod:Soulburn to a random enemy. |
| Rain of Embers | ![](small-card-images/RainofEmbers.png) | ![](small-card-images/RainofEmbersPlus.png) | Uncommon | Attack | X | Deal 7(8) damage and apply !burny! hexamod:Soulburn to a random enemy X times. If X is 3 or more, apply 1 (2) Weak and Vulnerable to ALL enemies. |
| Rewind | ![](small-card-images/Rewind.png) | ![](small-card-images/RewindPlus.png) | Uncommon | Skill | 0 | hexamod:Retract. Gain [E] (and draw 1 card). |
| Second Seal | ![](small-card-images/SecondSeal.png) | ![]() | Uncommon | Power | 1 | Ethereal hexamod:Seal. At the end of combat, gain 8 additional Gold. |
| Skip a Beat | ![](small-card-images/SkipaBeat.png) | ![](small-card-images/SkipaBeatPlus.png) | Uncommon | Skill | 1(0) | hexamod:Force-Ignite the next Ghostflame. Exhaust. |
| Spectral Spark | ![](small-card-images/SpectralSpark.png) | ![](small-card-images/SpectralSparkPlus.png) | Uncommon | Skill | 0 | Apply !burny! hexamod:Soulburn. If the hexamod:Active Ghostflame is hexamod:Ignited: hexamod:Extinguish it and return this card to your hand. |
| Speedrunning | ![](small-card-images/Speedrunning.png) | ![](small-card-images/SpeedrunningPlus.png) | Uncommon | Power | 1 | Whenever you hexamod:Advance, gain 2(3) Block. |
| Step Through | ![](small-card-images/StepThrough.png) | ![](small-card-images/StepThroughPlus.png) | Uncommon | Attack | 1 | Deal 6(9) damage. If the hexamod:Active Ghostflame is hexamod:Ignited, hexamod:Advance. If not, hexamod:Ignite it. |
| Third Seal | ![](small-card-images/ThirdSeal.png) | ![]() | Uncommon | Power | 1 | Ethereal hexamod:Seal. At the end of combat, gain an additional card reward. |
| Worthy Sacrifice | ![](small-card-images/WorthySacrifice.png) | ![](small-card-images/WorthySacrificePlus.png) | Uncommon | Skill | 0 | Choose an Attack or Skill to Exhaust. Add a random card of the opposite type into your hand.  (It costs 1 less.) |
| Apocalypse Now | ![](small-card-images/ApocalypseNow.png) | ![](small-card-images/ApocalypseNowPlus.png) | Rare | Skill | 0 | Ethereal. Gain [E] [E] ([E]). The Inferno Ghostflame becomes hexamod:Active. Exhaust. |
| Bad Omen | ![](small-card-images/BadOmen.png) | ![](small-card-images/BadOmenPlus.png) | Rare | Skill | 1 | Ethereal (Retain). Replace the hexamod:Active Ghostflame with a hexamod:Crushing or hexamod:Bolstering one. Exhaust. |
| Doomsday | ![](small-card-images/Doomsday.png) | ![](small-card-images/DoomsdayPlus.png) | Rare | Power | 0 | The next time you hexamod:Ignite the Inferno Ghostflame and all (at least) 6(5) Ghostflames are hexamod:Ignited, take an extra turn. |
| Fifth Seal | ![](small-card-images/FifthSeal.png) | ![]() | Rare | Power | 2 | Ethereal hexamod:Seal. At the end of combat, Upgrade a random card in your deck. |
| Forked Flame | ![](small-card-images/ForkedFlame.png) | ![](small-card-images/ForkedFlamePlus.png) | Rare | Attack | 1 | Deal 7 damage. hexamod:Force-Ignite the previous, then the (*Active, then the) next Ghostflames. |
| Gifts From Beyond | ![](small-card-images/GiftsFromBeyond.png) | ![](small-card-images/GiftsFromBeyondPlus.png) | Rare | Power |  | Unplayable. Ethereal. hexamod:Afterlife. Whenever an Ethereal card is Exhausted, gain [E] (and draw 1 card) next turn. |
| Here and Now | ![](small-card-images/HereandNow.png) | ![](small-card-images/HereandNowPlus.png) | Rare | Power | 1 | If you start and end your turn with the same Ghostflame active, gain 1(2) Strength. |
| Infernal Form | ![](small-card-images/InfernalForm.png) | ![](small-card-images/InfernalFormPlus.png) | Rare | Power | 3(2) | At the start of your turn, gain 1 hexamod:Intensity. |
| Instant Inferno | ![](small-card-images/InstantInferno.png) | ![](small-card-images/InstantInfernoPlus.png) | Rare | Skill | 1 | Retain. hexamod:Ignite the (hexamod:Active Ghostflame. hexamod:Ignite the) Inferno Ghostflame. Exhaust. |
| Poltergeist | ![](small-card-images/Poltergeist.png) | ![](small-card-images/PoltergeistPlus.png) | Rare | Power | 2 | Ethereal. Whenever you play an Ethereal card, deal 4(6) damage to a random enemy. |
| Searing Wound | ![](small-card-images/SearingWound.png) | ![](small-card-images/SearingWoundPlus.png) | Rare | Skill | 1 | ALL enemies lose HP equal to their hexamod:Soulburn. Exhaust. (not Exhaust.) |
| Sixth Seal | ![](small-card-images/SixthSeal.png) | ![]() | Rare | Power | 3 | Ethereal hexamod:Seal. At the end of combat, gain an additional non-Sixth Seal card reward. |
| Time Warp | ![](small-card-images/TimeWarp.png) | ![](small-card-images/TimeWarpPlus.png) | Rare | Attack | 0 | Deal 4(6) damage. Whenever you hexamod:Advance or hexamod:Retract, return this from the discard pile to your hand. |
| Time of Need | ![](small-card-images/TimeofNeed.png) | ![](small-card-images/TimeofNeedPlus.png) | Rare | Skill | 1(0) | Retain. Add a random Power card into your hand. It costs 0 until played. Exhaust. |
| Toasty! | ![](small-card-images/Toasty!.png) | ![](small-card-images/Toasty!Plus.png) | Rare | Attack | 2 | Deal 14(18) damage. Apply hexamod:Soulburn equal to unblocked damage dealt. |
| Turn It Up | ![](small-card-images/TurnItUp.png) | ![](small-card-images/TurnItUpPlus.png) | Rare | Skill | X | Gain 5 hexamod:Intensity. Lose it in X+1 (X+2) turns. Exhaust. |
| Unleash Spirits | ![](small-card-images/UnleashSpirits.png) | ![](small-card-images/UnleashSpiritsPlus.png) | Rare | Attack | 2 | Deal 5(7) damage to a random enemy. Repeat for each Ethereal card in your exhaust pile. Exhaust. |
| Unlimited Power | ![](small-card-images/UnlimitedPower.png) | ![](small-card-images/UnlimitedPowerPlus.png) | Rare | Skill | 5(4) | hexamod:Force-Ignite all Ghostflames in order. Exhaust. |
| Volcano Visage | ![](small-card-images/VolcanoVisage.png) | ![](small-card-images/VolcanoVisagePlus.png) | Rare | Power | 1 | Ethereal. At the start of your turn, apply 4(6) hexamod:Soulburn to ALL enemies. |
| Wildfire Weapon | ![](small-card-images/WildfireWeapon.png) | ![](small-card-images/WildfireWeaponPlus.png) | Rare | Power | 1 | Whenever an Attack deals unblocked damage, apply 3(4) hexamod:Soulburn. |
| Defend | ![](small-card-images/Defend.png) | ![](small-card-images/DefendPlus.png) | Basic | Skill | 1 | Gain 5(8) Block. |
| Goto | ![](small-card-images/Goto.png) | ![](small-card-images/GotoPlus.png) | Basic | Skill | 1 | Draw 1(2) card(s). bronze:Compile - Next turn, draw 1(2) card(s). |
| Replicate | ![](small-card-images/Replicate.png) | ![](small-card-images/ReplicatePlus.png) | Basic | Attack | 0 | Deal 4(6) damage. |
| Strike | ![](small-card-images/Strike.png) | ![](small-card-images/StrikePlus.png) | Basic | Attack | 1 | Deal 6(9) damage. |
| function() | ![](small-card-images/function().png) | ![]() | Special | Skill | 0 |  |
| Bit Shift | ![](small-card-images/BitShift.png) | ![](small-card-images/BitShiftPlus.png) | Common | Skill | 0 | (Retain.)  Choose a card in the Sequence to return to your hand. It gains Retain. Exhaust. |
| Branch | ![](small-card-images/Branch.png) | ![](small-card-images/BranchPlus.png) | Common | Attack | 1 | Choose - Deal 9(11) damage or gain 8(10) Block. bronze:Encode the option not chosen. Exhaust. |
| Bug Barrage | ![](small-card-images/BugBarrage.png) | ![](small-card-images/BugBarragePlus.png) | Common | Attack | 1 | Add 1 (1(2)) *Wound(s) to your hand. Deal 7 damage for each Status card in hand. |
| Buggy Mess | ![](small-card-images/BuggyMess.png) | ![](small-card-images/BuggyMessPlus.png) | Common | Skill | 1(0) | bronze:Insert random Status. Gain 1 [E] . |
| Constructor | ![](small-card-images/Constructor.png) | ![](small-card-images/ConstructorPlus.png) | Common | Skill | 1 | Gain 5(7) Block. π When bronze:Encoded, if this is the first card, increase its Block by 5(7). |
| Cut Through | ![](small-card-images/CutThrough.png) | ![](small-card-images/CutThroughPlus.png) | Common | Attack | 1 | Deal 5(7) damage. Scry 2(3). bronze:Compile - Draw !bauto! card. |
| Delayed Guard | ![](small-card-images/DelayedGuard.png) | ![](small-card-images/DelayedGuardPlus.png) | Common | Skill | 0 | Next turn, gain 7(10) Block. |
| Delayed Slice | ![](small-card-images/DelayedSlice.png) | ![](small-card-images/DelayedSlicePlus.png) | Common | Attack | 0 | Deal 3(4) damage. bronze:Compile - ALL enemies lose 6(10) HP. |
| Deprecate | ![](small-card-images/Deprecate.png) | ![](small-card-images/DeprecatePlus.png) | Common | Skill | 0 | Apply 1(2) Weak to ALL enemies. bronze:Compile *Error - Gain Weak. |
| Fine Tuning | ![](small-card-images/FineTuning.png) | ![](small-card-images/FineTuningPlus.png) | Common | Skill | 0 | (Retain.)  Increase all numbers on cards in the Sequence by 1. Exhaust. |
| Frontload | ![](small-card-images/Frontload.png) | ![](small-card-images/FrontloadPlus.png) | Common | Skill | 2 | Gain 12(16) Block. bronze:Compile - Function gains Retain. |
| Invalidate | ![](small-card-images/Invalidate.png) | ![](small-card-images/InvalidatePlus.png) | Common | Skill | 0 | Apply 1(2) Vulnerable to ALL enemies. bronze:Compile *Error - Gain Vulnerable. |
| Iterate | ![](small-card-images/Iterate.png) | ![](small-card-images/IteratePlus.png) | Common | Attack | 1 | Deal 2 damage 3(4) times. |
| Oil Spill | ![](small-card-images/OilSpill.png) | ![](small-card-images/OilSpillPlus.png) | Common | Attack | 1 | Deal 4(5) damage and apply 4(5) Poison. bronze:Compile *Error - bronze:Insert a *Slimed. |
| Overheat | ![](small-card-images/Overheat.png) | ![](small-card-images/OverheatPlus.png) | Common | Attack | 2 | Take 4 damage. Deal 18(22) damage. bronze:Compile *Error - bronze:Insert a *Burn+. |
| Piercing Shot | ![](small-card-images/PiercingShot.png) | ![](small-card-images/PiercingShotPlus.png) | Common | Attack | 1 | Deal 6(8) damage to ALL enemies. |
| Separator | ![](small-card-images/Separator.png) | ![](small-card-images/SeparatorPlus.png) | Common | Attack | 1 | Deal 6(8) damage. π When bronze:Encoded, if this is not in the first or last slot, increase its damage by 6(8). |
| Sticky Shield | ![](small-card-images/StickyShield.png) | ![](small-card-images/StickyShieldPlus.png) | Common | Skill | 1 | Gain 11(14) Block. bronze:Insert a *Slimed. |
| Turbo | ![](small-card-images/Turbo.png) | ![](small-card-images/TurboPlus.png) | Common | Skill | 0 | (Retain.)  Gain [E] [E]. bronze:Insert a *Void. |
| Wild Beam | ![](small-card-images/WildBeam.png) | ![](small-card-images/WildBeamPlus.png) | Common | Attack | 1 | Deal 10(13) damage. bronze:Compile *Error - bronze:Insert a *Wound. |
| Allocate | ![](small-card-images/Allocate.png) | ![](small-card-images/AllocatePlus.png) | Uncommon | Skill | 1(0) | Gain [E] for each Status in your draw pile. |
| Backtrace | ![](small-card-images/Backtrace.png) | ![](small-card-images/BacktracePlus.png) | Uncommon | Attack | 0 | Innate.   Deal 7(10) damage. bronze:Compile *Error - Function gains Exhaust. |
| Boost | ![](small-card-images/Boost.png) | ![](small-card-images/BoostPlus.png) | Uncommon | Skill | 2 | Gain 8 Block. bronze:Compile - Gain 2(3) Strength. |
| Bronze Armor | ![](small-card-images/BronzeArmor.png) | ![](small-card-images/BronzeArmorPlus.png) | Uncommon | Skill | 0 | Gain !bauto! Artifact. bronze:Compile *Error - ALL enemies gain 2(1) Artifact. |
| Bronze Orb | ![](small-card-images/BronzeOrb.png) | ![](small-card-images/BronzeOrbPlus.png) | Uncommon | Attack | 1 | Innate. Deal 6(9) damage. Gain 6(9) Block. bronze:Encode a random card with bronze:Encode in your draw pile. Exhaust. |
| Class Default | ![](small-card-images/ClassDefault.png) | ![](small-card-images/ClassDefaultPlus.png) | Uncommon | Power | 1 | (Retain.)  Add a copy of the first card in the current Sequence to the next 2 Sequences automatically. |
| Cultist Strike | ![](small-card-images/CultistStrike.png) | ![](small-card-images/CultistStrikePlus.png) | Uncommon | Attack | 1 | Deal 6(9) damage. bronze:Compile - Increase this card's damage by 1 permanently. |
| Dark Dash | ![](small-card-images/DarkDash.png) | ![](small-card-images/DarkDashPlus.png) | Uncommon | Attack | 2 | Gain 8(10) Block. Deal 8(10) damage. bronze:Compile *Error - bronze:Insert a *Void. |
| Digital Carnage | ![](small-card-images/DigitalCarnage.png) | ![](small-card-images/DigitalCarnagePlus.png) | Uncommon | Attack | 2 | Deal 20(28) damage. bronze:Compile *Error - Function is Ethereal. |
| Flail | ![](small-card-images/Flail.png) | ![](small-card-images/FlailPlus.png) | Uncommon | Attack | 2 | Deal 6(7) damage to ALL enemies !bauto! times. bronze:Compile - Gain 1(2) Artifact. |
| Follow Through | ![](small-card-images/FollowThrough.png) | ![](small-card-images/FollowThroughPlus.png) | Uncommon | Attack | 1 | Deal 7(9) damage. Gain 4(6) Block. If the last played card was a Function, play this again. |
| For Loop | ![](small-card-images/ForLoop.png) | ![](small-card-images/ForLoopPlus.png) | Uncommon | Skill | X | (Retain.)  The next card you bronze:Encode causes X additional copies to also be bronze:Encoded. Exhaust. |
| Force Shield | ![](small-card-images/ForceShield.png) | ![](small-card-images/ForceShieldPlus.png) | Uncommon | Skill | 4 | Costs 1 less [E] for each Function created this combat. Gain 12(16) Block. |
| Fortify | ![](small-card-images/Fortify.png) | ![](small-card-images/FortifyPlus.png) | Uncommon | Attack | 2 | Deal 8 damage. bronze:Compile - Gain 2(3) Dexterity. |
| Get Latest | ![](small-card-images/GetLatest.png) | ![](small-card-images/GetLatestPlus.png) | Uncommon | Skill | 1(0) | Add a random card with bronze:Encode to your hand. It costs 0. Exhaust. |
| Infinite Beams | ![](small-card-images/InfiniteBeams.png) | ![](small-card-images/InfiniteBeamsPlus.png) | Uncommon | Power | 1 | At the start of each turn, add a *Minor *Beam (*Beam+) to your hand. |
| Invoke | ![](small-card-images/Invoke.png) | ![](small-card-images/InvokePlus.png) | Uncommon | Skill | 0 | Gain 3(5) Block. bronze:Compile - Gain [E] equal to the total cost of cards in the Sequence. |
| It's a Feature | ![](small-card-images/ItsaFeature.png) | ![](small-card-images/ItsaFeaturePlus.png) | Uncommon | Power | 1 | (Innate.)  Whenever you draw a Curse or Status card, gain 1 Temporary Strength and Dexterity. |
| Max Output | ![](small-card-images/MaxOutput.png) | ![](small-card-images/MaxOutputPlus.png) | Uncommon | Power | 1(0) | Draw 3 cards. At the start of each turn, draw 1 additional card and bronze:Insert 1 *Dazed. |
| Merge Conflict | ![](small-card-images/MergeConflict.png) | ![](small-card-images/MergeConflictPlus.png) | Uncommon | Attack | 2 | Deal 10 damage. The next time you bronze:Encode a card, bronze:Encode a copy of it. Exhaust. (not Exhaust.) |
| Null Pointer | ![](small-card-images/NullPointer.png) | ![](small-card-images/NullPointerPlus.png) | Uncommon | Attack | 1 | Deal 12(15) damage. Gain 12(15) Block. bronze:Compile *Error - Function is Unplayable. |
| Optimize | ![](small-card-images/Optimize.png) | ![](small-card-images/OptimizePlus.png) | Uncommon | Power | 0 | Upgrade the next 3(5) cards you bronze:Encode that can be upgraded. |
| Overload | ![](small-card-images/Overload.png) | ![](small-card-images/OverloadPlus.png) | Uncommon | Skill | 1 | Play a copy of each card in the Sequence. They do not Encode. Exhaust. (not Exhaust.) |
| Philosophize | ![](small-card-images/Philosophize.png) | ![](small-card-images/PhilosophizePlus.png) | Uncommon | Skill | 1 | Gain !bauto! Strength. bronze:Compile *Error - ALL enemies gain 2(1) Strength. |
| Refactor | ![](small-card-images/Refactor.png) | ![](small-card-images/RefactorPlus.png) | Uncommon | Skill | 1 | Scry 5. Exhaust all cards discarded. Gain 5(7) Block for each Status card exhausted. |
| Repair | ![](small-card-images/Repair.png) | ![](small-card-images/RepairPlus.png) | Uncommon | Skill | 1 | Gain 4 Block. bronze:Compile - Heal 7(10) HP. |
| Repulsor | ![](small-card-images/Repulsor.png) | ![](small-card-images/RepulsorPlus.png) | Uncommon | Power | 2 | (Innate.)  When you draw the first Status or Curse card each turn, Exhaust it and draw a card. |
| Return | ![](small-card-images/Return.png) | ![](small-card-images/ReturnPlus.png) | Uncommon | Skill | X | Gain [E] and draw 1 additional card at the start of your next X turns. Gain [E]. Exhaust. (not Exhaust.) |
| Safeguard | ![](small-card-images/Safeguard.png) | ![](small-card-images/SafeguardPlus.png) | Uncommon | Skill | 1 | Gain 10(13) Block. bronze:Compile *Error - Gain 2 Frail. |
| Shell | ![](small-card-images/Shell.png) | ![](small-card-images/ShellPlus.png) | Uncommon | Skill | 0 | Gain 1 bronze:Blur.  (bronze:Compile - Gain 1 bronze:Blur.) |
| Terminator | ![](small-card-images/Terminator.png) | ![](small-card-images/TerminatorPlus.png) | Uncommon | Skill | 1(0) | bronze:Compile - If this is the last card in the Sequence, Function gains 'Play this again'. |
| Assembly | ![](small-card-images/Assembly.png) | ![](small-card-images/AssemblyPlus.png) | Rare | Skill | 1 | Scry 5(8). bronze:Encode all cards with bronze:Encode discarded. Exhaust. |
| Break | ![](small-card-images/Break.png) | ![](small-card-images/BreakPlus.png) | Rare | Attack | 1 | Deal 15(18) damage. bronze:Compile *Error - bronze:Insert 4(3) random Status cards. |
| Burn Out | ![](small-card-images/BurnOut.png) | ![](small-card-images/BurnOutPlus.png) | Rare | Attack | 2 | Deal 5(8) damage to a random enemy for ALL of your Status cards, then Exhaust them. bronze:Insert 3 *Burns. |
| Clean Code | ![](small-card-images/CleanCode.png) | ![](small-card-images/CleanCodePlus.png) | Rare | Power | 2 | Remove all bronze:Compile *Error effects from cards in the Sequence. Lasts for the next 3(4) Functions created. |
| Dev Tools | ![](small-card-images/DevTools.png) | ![](small-card-images/DevToolsPlus.png) | Rare | Skill | 0 | Retain. Choose between *Debug, *Batch, *Decompile, and *Byte *Shift. Exhaust. (not Exhaust.) |
| Early Access | ![](small-card-images/EarlyAccess.png) | ![](small-card-images/EarlyAccessPlus.png) | Rare | Attack | 2 | (Innate.  ) Deal 15 damage. bronze:Insert random Status. bronze:Compile - bronze:Insert *Beta *Build. |
| Find and Replace | ![](small-card-images/FindandReplace.png) | ![](small-card-images/FindandReplacePlus.png) | Rare | Skill | 0 | Ethereal (Retain). Put a card from your draw or discard pile into your hand. Add a Dazed where it was. Exhaust. |
| Format | ![](small-card-images/Format.png) | ![](small-card-images/FormatPlus.png) | Rare | Skill | X | bronze:Encode X (X+1) copies of *Fragment. Gain [E]. Exhaust. |
| HYPER BEAM | ![](small-card-images/HYPERBEAM.png) | ![](small-card-images/HYPERBEAMPlus.png) | Rare | Attack | 6(5) | Retain. Deal 45 damage to ALL enemies. Put 5 *Void on top of your draw pile. When Retained, lower its cost by 1 this combat. |
| Hardcode | ![](small-card-images/Hardcode.png) | ![](small-card-images/HardcodePlus.png) | Rare | Power | 3(0) | Fleeting. The next Function you create goes into your deck permanently instead of your hand. |
| Infinite Loop | ![](small-card-images/InfiniteLoop.png) | ![](small-card-images/InfiniteLoopPlus.png) | Rare | Attack | 1 | Deal 6 damage. bronze:Compile - Add a copy of this into your hand and increase its damage by 2(3). |
| Library | ![](small-card-images/Library.png) | ![](small-card-images/LibraryPlus.png) | Rare | Power | 3(2) | At the start of your turn, add a random card with bronze:Encode to your hand. It costs 0. |
| Mutator | ![](small-card-images/Mutator.png) | ![](small-card-images/MutatorPlus.png) | Rare | Power | 1 | (Retain.)  Gain 1 Strength. Transform a Status in your hand into a copy of this. |
| Recursive Strike | ![](small-card-images/RecursiveStrike.png) | ![](small-card-images/RecursiveStrikePlus.png) | Rare | Attack | 2 | Deal 6(9) damage 2 times. bronze:Compile - bronze:Encode 2 copies of *Strike (*Strike+). |
| Sentient Form | ![](small-card-images/SentientForm.png) | ![](small-card-images/SentientFormPlus.png) | Rare | Power | 3 | Ethereal. (not Ethereal.) The first time you create or draw a Function each turn, increase all numbers on it by 1. |
| Ship It | ![](small-card-images/ShipIt.png) | ![](small-card-images/ShipItPlus.png) | Rare | Attack | 1 | Deal 5 damage. Deals 2(3) additional damage for ALL of your Status cards. |
| Spaghetti Code | ![](small-card-images/SpaghettiCode.png) | ![](small-card-images/SpaghettiCodePlus.png) | Rare | Skill | 2(1) | Until the Sequence is full, choose 1 of 3 random cards to bronze:Encode. Exhaust. |
| Summon Orb | ![](small-card-images/SummonOrb.png) | ![](small-card-images/SummonOrbPlus.png) | Rare | Power | 2 | Whenever you create or play a Function, gain 4(6) Block and deal 4(6) damage to a random enemy. |
| Thunder Wave | ![](small-card-images/ThunderWave.png) | ![](small-card-images/ThunderWavePlus.png) | Rare | Attack | 2 | Deal 7(9) damage to a random enemy for each Function created this combat. |
| Virus | ![](small-card-images/Virus.png) | ![](small-card-images/VirusPlus.png) | Rare | Attack | 1 | Retain. Deal 3(4) damage. Transform all cards in hand into *Minor *Beam (*Beam+). Exhaust. |
| Corrosive Spit | ![](small-card-images/CorrosiveSpit.png) | ![](small-card-images/CorrosiveSpitPlus.png) | Basic | Skill | 1(0) | Apply !SlimeboundSlimed! slimeboundmod:Goop. |
| Defend | ![](small-card-images/Defend.png) | ![](small-card-images/DefendPlus.png) | Basic | Skill | 1 | Gain 5(8) Block. |
| Split | ![](small-card-images/Split.png) | ![](small-card-images/SplitPlus.png) | Basic | Skill | 1 | Choose 1 (2) of 4 Slimes to slimeboundmod:Split into. Exhaust. |
| Strike | ![](small-card-images/Strike.png) | ![](small-card-images/StrikePlus.png) | Basic | Attack | 1 | Deal 6(9) damage. |
| Tackle | ![](small-card-images/Tackle.png) | ![](small-card-images/TacklePlus.png) | Basic | Attack | 1 | Deal 12(16) damage and !SlimeboundSelfharm! damage to yourself. |
| Combo Tackle | ![](small-card-images/ComboTackle.png) | ![](small-card-images/ComboTacklePlus.png) | Common | Attack | 2 | Deal 12(15) damage and !SlimeboundSelfharm! damage to yourself. Add a random (Upgraded) slimeboundmod:Tackle card to your hand. It costs 0 this turn. |
| Goop Spray | ![](small-card-images/GoopSpray.png) | ![](small-card-images/GoopSprayPlus.png) | Common | Skill | 1 | Gain 5(6) Block. Apply !SlimeboundSlimed! slimeboundmod:Goop and 1(2) Weak to ALL enemies. |
| Growth Punch | ![](small-card-images/GrowthPunch.png) | ![](small-card-images/GrowthPunchPlus.png) | Common | Attack | 1 | Deal 4(5) damage. Gain 4(5) Block. slimeboundmod:Consume - Increase this card's effects by 4(5) this combat. |
| It Looks Tasty | ![](small-card-images/ItLooksTasty.png) | ![](small-card-images/ItLooksTastyPlus.png) | Common | Attack | 1 | Deal 8(10) damage. slimeboundmod:Consume - Add a *Lick (*Lick+) to your hand. |
| Leech Energy | ![](small-card-images/LeechEnergy.png) | ![](small-card-images/LeechEnergyPlus.png) | Common | Attack | 1 | Deal 5 damage. slimeboundmod:Consume - Gain [E] and draw 1(2) card(s). |
| Leeching Strike | ![](small-card-images/LeechingStrike.png) | ![](small-card-images/LeechingStrikePlus.png) | Common | Attack | 1 | Deal 5(8) damage. slimeboundmod:Consume - Gain Block equal to the enemy's slimeboundmod:Goop. |
| Living Wall | ![](small-card-images/LivingWall.png) | ![](small-card-images/LivingWallPlus.png) | Common | Skill | 2 | Gain 12(15) Block. Apply !SlimeboundSlimed! slimeboundmod:Goop to attackers this turn. |
| Opening Tackle | ![](small-card-images/OpeningTackle.png) | ![](small-card-images/OpeningTacklePlus.png) | Common | Attack | 1 | Deal 11(14) damage and !SlimeboundSelfharm! damage to yourself. slimeboundmod:Consume - Apply 2(3) Vulnerable. |
| Prepare | ![](small-card-images/Prepare.png) | ![](small-card-images/PreparePlus.png) | Common | Skill | 2 | Gain 10(15) Block. Next turn, gain [E] [E] and draw 2 cards. Exhaust. |
| Press the Attack | ![](small-card-images/PresstheAttack.png) | ![](small-card-images/PresstheAttackPlus.png) | Common | Attack | 1 | Deal 9 damage. slimeboundmod:Consume - slimeboundmod:Command (twice). |
| Roll Through | ![](small-card-images/RollThrough.png) | ![](small-card-images/RollThroughPlus.png) | Common | Attack | 1 | Deal 5(7) damage to ALL enemies. You do not take damage from the next 2(3) slimeboundmod:Tackle cards. |
| Sampling Lick | ![](small-card-images/SamplingLick.png) | ![](small-card-images/SamplingLickPlus.png) | Common | Skill | 0 | Apply !SlimeboundSlimed! slimeboundmod:Goop. Gain 4 Block. (Draw a card.)  Exhaust. |
| Schlurp | ![](small-card-images/Schlurp.png) | ![](small-card-images/SchlurpPlus.png) | Common | Skill | 1 | Gain 6 Block. Add 2(3) *Licks to your hand. |
| Slime Spikes | ![](small-card-images/SlimeSpikes.png) | ![](small-card-images/SlimeSpikesPlus.png) | Common | Skill | 1 | Gain 7(9) Block and 3(4) temporary Thorns. |
| Spear Tackle | ![](small-card-images/SpearTackle.png) | ![](small-card-images/SpearTacklePlus.png) | Common | Attack | 1 | Deal 11(13) damage and !SlimeboundSelfharm! damage to yourself. Draw 2(3) cards. |
| Split: Bruiser | ![](small-card-images/Split-Bruiser.png) | ![](small-card-images/Split-BruiserPlus.png) | Common | Skill | 1 | slimeboundmod:Split into a slimeboundmod:Bruiser_Slime. slimeboundmod:Command 2(3) times. Exhaust. |
| Split: Guerilla | ![](small-card-images/Split-Guerilla.png) | ![](small-card-images/Split-GuerillaPlus.png) | Common | Skill | 1 | slimeboundmod:Split into a slimeboundmod:Guerilla_Slime. slimeboundmod:Command 2(3) times. Exhaust. |
| Split: Leeching | ![](small-card-images/Split-Leeching.png) | ![](small-card-images/Split-LeechingPlus.png) | Common | Skill | 1 | slimeboundmod:Split into a slimeboundmod:Leeching_Slime. slimeboundmod:Command 2(3) times. Exhaust. |
| Split: Mire | ![](small-card-images/Split-Mire.png) | ![](small-card-images/Split-MirePlus.png) | Common | Skill | 1 | slimeboundmod:Split into a slimeboundmod:Mire_Slime. slimeboundmod:Command 2(3) times. Exhaust. |
| Chomp | ![](small-card-images/Chomp.png) | ![](small-card-images/ChompPlus.png) | Uncommon | Attack | 1 | Deal 8(10) damage. Reduce the cost of a random slimeboundmod:Tackle card in your hand to 0 this turn (combat). |
| Disrupting Slam | ![](small-card-images/DisruptingSlam.png) | ![](small-card-images/DisruptingSlamPlus.png) | Uncommon | Attack | 1 | Deal 5(8) damage to ALL enemies. Apply 1(2) Weak to each enemy that intends to attack. |
| Dissolve | ![](small-card-images/Dissolve.png) | ![](small-card-images/DissolvePlus.png) | Uncommon | Skill | 0 | Draw a card, then Exhaust a card in your hand. Add a number of *Licks to your hand equal to it's cost (plus 1). Exhaust. |
| Divide & Conquer | ![](small-card-images/Divide&Conquer.png) | ![](small-card-images/Divide&ConquerPlus.png) | Uncommon | Attack | 1 | Deal 10(15) damage to a random enemy for each Slime. slimeboundmod:Absorb all Slimes. Exhaust. |
| Double Lick | ![](small-card-images/DoubleLick.png) | ![](small-card-images/DoubleLickPlus.png) | Uncommon | Skill | 0 | Apply !SlimeboundSlimed! slimeboundmod:Goop. Add a *Lick to your hand. (Draw a card.)  Exhaust. |
| Equalize | ![](small-card-images/Equalize.png) | ![](small-card-images/EqualizePlus.png) | Uncommon | Attack | 2 | Deal 8(12) damage. Heal 2(4) HP. slimeboundmod:Consume - Play this twice. Exhaust. |
| Flame Tackle | ![](small-card-images/FlameTackle.png) | ![](small-card-images/FlameTacklePlus.png) | Uncommon | Attack | 2 | Deal 16(19) damage and !SlimeboundSelfharm! damage to yourself. slimeboundmod:Tackles deal 3(4) more damage this combat. |
| Forward Tackle | ![](small-card-images/ForwardTackle.png) | ![](small-card-images/ForwardTacklePlus.png) | Uncommon | Attack | 2 | Deal 15(17) damage and !SlimeboundSelfharm! damage to yourself. slimeboundmod:Command twice (three times). |
| Gluttony | ![](small-card-images/Gluttony.png) | ![](small-card-images/GluttonyPlus.png) | Uncommon | Power | 1 | (Innate.)  The first time you slimeboundmod:Consume each turn, add a *Lick to your hand. |
| Goop Armor | ![](small-card-images/GoopArmor.png) | ![](small-card-images/GoopArmorPlus.png) | Uncommon | Power | 1 | Gain 3(4) Block whenever you slimeboundmod:Consume. |
| Grow | ![](small-card-images/Grow.png) | ![](small-card-images/GrowPlus.png) | Uncommon | Power | 2(1) | Lose 1 Slime slot in exchange for 2 Strength and 2 Dexterity. |
| Haunting Lick | ![](small-card-images/HauntingLick.png) | ![](small-card-images/HauntingLickPlus.png) | Uncommon | Skill | 0 | Apply 1 Vulnerable and !SlimeboundSlimed! slimeboundmod:Goop. (Draw a card.)  Exhaust. |
| Hungry Tackle | ![](small-card-images/HungryTackle.png) | ![](small-card-images/HungryTacklePlus.png) | Uncommon | Attack | 1 | Deal 10(14) damage and !SlimeboundSelfharm! damage to yourself. Return a random 0-cost Exhausted card to your hand. |
| Lead By Example | ![](small-card-images/LeadByExample.png) | ![](small-card-images/LeadByExamplePlus.png) | Uncommon | Power | 1 | The first (1(2)) card(s) you play each turn that targets enemies also slimeboundmod:Commands. |
| Level Up | ![](small-card-images/LevelUp.png) | ![](small-card-images/LevelUpPlus.png) | Uncommon | Power | 1 | Gain 1(2) slimeboundmod:Potency. |
| Mega-Lick | ![](small-card-images/Mega-Lick.png) | ![](small-card-images/Mega-LickPlus.png) | Uncommon | Skill | 0 | Apply 1 Weak and !SlimeboundSlimed! slimeboundmod:Goop to ALL enemies. (Draw a card.)  Exhaust. |
| Nibble | ![](small-card-images/Nibble.png) | ![](small-card-images/NibblePlus.png) | Uncommon | Attack | 0 | Deal 4(6) damage. Add a random (Upgraded) 0-cost card to your hand. Exhaust. |
| Pile On! | ![](small-card-images/PileOn!.png) | ![](small-card-images/PileOn!Plus.png) | Uncommon | Attack | 2 | Deal 8 damage. slimeboundmod:Command ALL slimes (twice). |
| Protect the Boss | ![](small-card-images/ProtecttheBoss.png) | ![](small-card-images/ProtecttheBossPlus.png) | Uncommon | Power | 1(0) | Prevent the next time you would be damaged by an enemy attack, slimeboundmod:Absorbing your leading Slime instead. |
| Rain of Goop | ![](small-card-images/RainofGoop.png) | ![](small-card-images/RainofGoopPlus.png) | Uncommon | Skill | 1 | Apply !SlimeboundSlimed! slimeboundmod:Goop to a random enemy 4(6) times. |
| Recklessness | ![](small-card-images/Recklessness.png) | ![](small-card-images/RecklessnessPlus.png) | Uncommon | Power | 1 | slimeboundmod:Tackles deal 5(7) more damage to enemies, and 1 more damage to you. |
| Recollect | ![](small-card-images/Recollect.png) | ![](small-card-images/RecollectPlus.png) | Uncommon | Skill | 1 | Gain 8(11) Block. Return a random 0-cost Exhausted card to your hand. |
| Replication | ![](small-card-images/Replication.png) | ![](small-card-images/ReplicationPlus.png) | Uncommon | Skill | 1 | Choose a card in your hand. Put (Add) a copy of that card on top of (it into) your draw pile (hand). Exhaust. |
| Repurpose | ![](small-card-images/Repurpose.png) | ![](small-card-images/RepurposePlus.png) | Uncommon | Skill | 0 | slimeboundmod:Absorb - Split into a random slimeboundmod:Specialist Slime. (slimeboundmod:Command.)  Exhaust. |
| Serve & Protect | ![](small-card-images/Serve&Protect.png) | ![](small-card-images/Serve&ProtectPlus.png) | Uncommon | Skill | 1 | Gain 10(15) Block and 1 bronze:Blur for each Slime. slimeboundmod:Absorb all Slimes. Exhaust. |
| Shape of Puddle | ![](small-card-images/ShapeofPuddle.png) | ![](small-card-images/ShapeofPuddlePlus.png) | Uncommon | Skill | 3(2) | Gain 1 Intangible. Exhaust. |
| Slime Brawl | ![](small-card-images/SlimeBrawl.png) | ![](small-card-images/SlimeBrawlPlus.png) | Uncommon | Skill | 3(2) | Play the top card of your draw pile. Repeat for each of your spawned Slimes. Exhaust. |
| Slime Tap | ![](small-card-images/SlimeTap.png) | ![](small-card-images/SlimeTapPlus.png) | Uncommon | Skill | 0 | slimeboundmod:Absorb - Gain [E] [E] and draw 2(3) cards. Exhaust. |
| Split: Specialist | ![](small-card-images/Split-Specialist.png) | ![](small-card-images/Split-SpecialistPlus.png) | Uncommon | Skill | 1 | Choose 1 of 3 slimeboundmod:Specialist Slimes to slimeboundmod:Split into. (slimeboundmod:Command.)  Exhaust. |
| Spreading Slime | ![](small-card-images/SpreadingSlime.png) | ![](small-card-images/SpreadingSlimePlus.png) | Uncommon | Power | 2 | Effects that apply slimeboundmod:Goop apply 2(3) more. |
| Tongue Lash | ![](small-card-images/TongueLash.png) | ![](small-card-images/TongueLashPlus.png) | Uncommon | Attack | 1 | Deal 6 damage. Deals 2(3) additional damage for each Exhausted card containing "Lick". |
| Vicious Tackle | ![](small-card-images/ViciousTackle.png) | ![](small-card-images/ViciousTacklePlus.png) | Uncommon | Attack | 2 | Deal 16(20) damage and !SlimeboundSelfharm! damage to yourself. This gains twice the damage bonus from slimeboundmod:Goop. |
| Consult Playbook | ![](small-card-images/ConsultPlaybook.png) | ![](small-card-images/ConsultPlaybookPlus.png) | Rare | Skill | 2(1) | Add 4 random slimeboundmod:Tackle cards to your hand. They cost 1 less this combat. Exhaust. |
| Darkling Trio | ![](small-card-images/DarklingTrio.png) | ![](small-card-images/DarklingTrioPlus.png) | Rare | Skill | 1 | slimeboundmod:Split into a slimeboundmod:Darkling_Slime 2(3) times. Exhaust. |
| Douse in Slime | ![](small-card-images/DouseinSlime.png) | ![](small-card-images/DouseinSlimePlus.png) | Rare | Skill | 3(2) | Apply !SlimeboundSlimed! slimeboundmod:Goop. The next Attack used on this enemy does not remove slimeboundmod:Goop. |
| Duplicated Form | ![](small-card-images/DuplicatedForm.png) | ![](small-card-images/DuplicatedFormPlus.png) | Rare | Power | 3 | Lose 15 HP and 15 Max HP this combat. (Gain [E] each turn.)  The first card you play each turn that targets enemies is played twice. |
| Leech Life | ![](small-card-images/LeechLife.png) | ![](small-card-images/LeechLifePlus.png) | Rare | Attack | 2 | Deal 12(18) damage. slimeboundmod:Consume - Heal HP equal to the enemy's slimeboundmod:Goop. Exhaust. |
| Liquidate | ![](small-card-images/Liquidate.png) | ![](small-card-images/LiquidatePlus.png) | Rare | Skill | 0 | Cannot be used if you have negative Strength. Lose 2 Strength. Gain 2(3) slimeboundmod:Potency. |
| Mass Feed | ![](small-card-images/MassFeed.png) | ![](small-card-images/MassFeedPlus.png) | Rare | Attack | 2 | Deal 10(12) damage to ALL enemies. If Fatal, raise your Max HP by 3(4). Exhaust. |
| Mass Repurpose | ![](small-card-images/MassRepurpose.png) | ![](small-card-images/MassRepurposePlus.png) | Rare | Skill | 1 | slimeboundmod:Absorb ALL Slimes. Split into a random slimeboundmod:Specialist Slime for each slimeboundmod:Absorbed (, then slimeboundmod:Command them all). Exhaust. |
| Minion Master | ![](small-card-images/MinionMaster.png) | ![](small-card-images/MinionMasterPlus.png) | Rare | Power | 2 | (Innate.)  Whenever you play a card that triggers slimeboundmod:Command, slimeboundmod:Command again. |
| One-Two Combo | ![](small-card-images/One-TwoCombo.png) | ![](small-card-images/One-TwoComboPlus.png) | Rare | Attack | 0 | Deal 3 damage. (slimeboundmod:Command.)  When you slimeboundmod:Split, return this from the discard pile to your hand. |
| Ooze Bath | ![](small-card-images/OozeBath.png) | ![](small-card-images/OozeBathPlus.png) | Rare | Skill | 0 | Apply 3(5) slimeboundmod:Goop to target enemy at the start of each of its turns. Exhaust. |
| Overexert | ![](small-card-images/Overexert.png) | ![](small-card-images/OverexertPlus.png) | Rare | Power | 1 | Gain 4 slimeboundmod:Potency. (slimeboundmod:Command twice.)  2 turns from now, slimeboundmod:Absorb all Slimes. |
| Prepare: Crush | ![](small-card-images/Prepare-Crush.png) | ![](small-card-images/Prepare-CrushPlus.png) | Rare | Skill | 3(2) | Next turn, gain [E] [E] [E] and 3 Strength, and add Slime Crush to your hand. |
| Rally the Troops | ![](small-card-images/RallytheTroops.png) | ![](small-card-images/RallytheTroopsPlus.png) | Rare | Attack | 1 | Deal 7(9) damage. The next 2(3) cards played this turn trigger a slimeboundmod:Command. |
| Recycling | ![](small-card-images/Recycling.png) | ![](small-card-images/RecyclingPlus.png) | Rare | Power | 1 | (Innate.)  At the start of your turn, return a random Exhausted 0-cost card to your hand. |
| Reformation | ![](small-card-images/Reformation.png) | ![](small-card-images/ReformationPlus.png) | Rare | Power | 1 | When you slimeboundmod:Absorb a Slime, gain 1 Strength (and 1 Dexterity). |
| Slime Slap | ![](small-card-images/SlimeSlap.png) | ![](small-card-images/SlimeSlapPlus.png) | Rare | Attack | 2(1) | Deal 8 damage. slimeboundmod:Consume - Does not remove slimeboundmod:Goop. |
| Tag Team | ![](small-card-images/TagTeam.png) | ![](small-card-images/TagTeamPlus.png) | Rare | Attack | 2 | Deal 12 damage. slimeboundmod:Split into a random (slimeboundmod:Specialist) Slime. slimeboundmod:Command 2(3) times. |
| Teamwork | ![](small-card-images/Teamwork.png) | ![](small-card-images/TeamworkPlus.png) | Rare | Skill | X | slimeboundmod:Command X (X+1) times. Gain 5 Block X (X+1) times. |
| Waste Not | ![](small-card-images/WasteNot.png) | ![](small-card-images/WasteNotPlus.png) | Rare | Skill | 3(2) | Return all 0-cost Exhausted cards to your hand. Exhaust. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Basic | Skill |  | *Unknown (Upgraded) Card. |
| Defend | ![](small-card-images/Defend.png) | ![](small-card-images/DefendPlus.png) | Basic | Skill | 1 | Gain 5(8) Block. |
| Snek Bite | ![](small-card-images/SnekBite.png) | ![](small-card-images/SnekBitePlus.png) | Basic | Attack | 1 | Deal 9(11) damage. sneckomod:Muddle the (1(2)) highest-cost card(s) in your hand. |
| Strike | ![](small-card-images/Strike.png) | ![](small-card-images/StrikePlus.png) | Basic | Attack | 1 | Deal 6(9) damage. |
| Tail Whip | ![](small-card-images/TailWhip.png) | ![](small-card-images/TailWhipPlus.png) | Basic | Attack | 2 | Deal 10(13) damage. Apply 0(1) - 2 Weak. Apply 0(1) - 2 Vulnerable. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Common | Skill |  | *Unknown (Upgraded) Character Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Common | Skill |  | *Unknown (Upgraded) Character Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Common | Skill |  | *Unknown (Upgraded) Character Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Common | Attack |  | *Unknown (Upgraded) Common Attack Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Common | Skill |  | *Unknown (Upgraded) Character Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Common | Skill |  | *Unknown (Upgraded) Block Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Common | Skill |  | *Unknown (Upgraded) Character Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Common | Skill |  | *Unknown (Upgraded) Character Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Common | Skill |  | *Unknown (Upgraded) Character Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Common | Skill |  | *Unknown (Upgraded) Common Skill Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Common | Skill |  | *Unknown (Upgraded) 1 Cost Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Common | Skill |  | *Unknown (Upgraded) Draw Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Common | Skill |  | *Unknown (Upgraded) Character Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Common | Skill |  | *Unknown (Upgraded) Character Card. |
| Dice Block | ![](small-card-images/DiceBlock.png) | ![](small-card-images/DiceBlockPlus.png) | Common | Skill | 1 | Gain 1 - 10(14) Block. Maximum Block is increased by 1 for each *Unknown card you started combat with. |
| Dice Crush | ![](small-card-images/DiceCrush.png) | ![](small-card-images/DiceCrushPlus.png) | Common | Attack | 1 | Deal 1 - 10(14) damage. Maximum damage is increased by 1 for each *Unknown card you started combat with. |
| Iron Fang | ![](small-card-images/IronFang.png) | ![](small-card-images/IronFangPlus.png) | Common | Attack | 1 | Deal !qqq! - 7(9) damage. Gain 3 - 7(9) Block. |
| Nope | ![](small-card-images/Nope.png) | ![](small-card-images/NopePlus.png) | Common | Skill | 0 | sneckomod:Snekproof. Exhaust a card in your hand. Replace it with a random card of the same type that costs 1 less. Exhaust. (not Exhaust.) |
| Quick Move | ![](small-card-images/QuickMove.png) | ![](small-card-images/QuickMovePlus.png) | Common | Skill | 1 | Gain 8(10) Block. sneckomod:Muddle the (1(2)) highest-cost card(s) in your hand. |
| Rain of Dice | ![](small-card-images/RainofDice.png) | ![](small-card-images/RainofDicePlus.png) | Common | Attack | 1 | Deal !qqq! - 4(5) damage to a random enemy 2 - 4(5) times. |
| Snake Rake | ![](small-card-images/SnakeRake.png) | ![](small-card-images/SnakeRakePlus.png) | Common | Attack | 1 | Deal 9(12) damage. Draw 0(1) - 2 cards. sneckomod:Muddle the highest-cost card in your hand. |
| Soul Draw | ![](small-card-images/SoulDraw.png) | ![](small-card-images/SoulDrawPlus.png) | Common | Skill | 1 | sneckomod:Snekproof. Draw 0 (1) - 4(5) cards. |
| Soul Roll | ![](small-card-images/SoulRoll.png) | ![](small-card-images/SoulRollPlus.png) | Common | Skill | 0 | sneckomod:Snekproof. sneckomod:Muddle your hand.  (Draw 1 card.) |
| Wide Sting | ![](small-card-images/WideSting.png) | ![](small-card-images/WideStingPlus.png) | Common | Attack | 2(1) | Deal 7 - 12 damage to ALL enemies. Upgrade all sneckomod:Offclass cards in your hand. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Uncommon | Skill |  | *Unknown (Upgraded) Weak Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Uncommon | Attack |  | *Unknown (Upgraded) Uncommon Attack Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Uncommon | Skill |  | *Unknown (Upgraded) Uncommon Skill Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Uncommon | Skill |  | *Unknown (Upgraded) Colorless Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Uncommon | Power |  | *Unknown (Upgraded) Uncommon Power Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Uncommon | Skill |  | *Unknown (Upgraded) X Cost Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Uncommon | Skill |  | *Unknown (Upgraded) 2 Cost Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Uncommon | Skill |  | *Unknown (Upgraded) Strength Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Uncommon | Skill |  | *Unknown (Upgraded) 0 Cost Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Uncommon | Attack |  | *Unknown (Upgraded) Strike Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Uncommon | Skill |  | *Unknown (Upgraded) Dexterity Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Uncommon | Skill |  | *Unknown (Upgraded) Vulnerable Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Uncommon | Skill |  | *Unknown (Upgraded) Exhaust Card. |
| Cheap Stock | ![](small-card-images/CheapStock.png) | ![](small-card-images/CheapStockPlus.png) | Uncommon | Power | 2 | (Innate.)  At the start of your turn, reduce the cost of the highest cost sneckomod:Offclass card in your hand by 1. |
| Defensive Flair | ![](small-card-images/DefensiveFlair.png) | ![](small-card-images/DefensiveFlairPlus.png) | Uncommon | Skill | 1 | Gain 6(7) Block, increased by 1(2) for each sneckomod:Offclass card in your hand. |
| Dice Boulder | ![](small-card-images/DiceBoulder.png) | ![](small-card-images/DiceBoulderPlus1.png) | Uncommon | Attack | 2 | Deal 1(9) - 30(34) damage. Can be Upgraded any number of times. |
| Improvised Attack | ![](small-card-images/ImprovisedAttack.png) | ![](small-card-images/ImprovisedAttackPlus.png) | Uncommon | Attack | 1 | Deal 8(11) damage. Add a random sneckomod:Offclass Attack into your hand and sneckomod:Muddle it. |
| Improvised Guard | ![](small-card-images/ImprovisedGuard.png) | ![](small-card-images/ImprovisedGuardPlus.png) | Uncommon | Skill | 1 | Gain 7(10) Block. Add a random sneckomod:Offclass Skill into your hand and sneckomod:Muddle it. |
| Master Eye | ![](small-card-images/MasterEye.png) | ![](small-card-images/MasterEyePlus.png) | Uncommon | Power | 1 | Become Confused. Draw 1(2) additional card(s) each turn. |
| Memorize | ![](small-card-images/Memorize.png) | ![](small-card-images/MemorizePlus.png) | Uncommon | Skill | 0 | sneckomod:Snekproof. Fleeting. (Retain.) Choose a card in hand which started *Unknown. Permanently add it to your deck, removing its *Unknown. |
| Mix It Up! | ![](small-card-images/MixItUp!.png) | ![](small-card-images/MixItUp!Plus.png) | Uncommon | Attack | 1 | Deal 5(7) damage for each of your Potions. Lose your Potions and replace them with new ones. Exhaust. |
| Rotation | ![](small-card-images/Rotation.png) | ![](small-card-images/RotationPlus.png) | Uncommon | Skill | 0 | sneckomod:Snekproof. Discard all sneckomod:Offclass cards. Draw that many cards plus 1(2). |
| Serpent Idol | ![](small-card-images/SerpentIdol.png) | ![](small-card-images/SerpentIdolPlus.png) | Uncommon | Skill | 1(0) | sneckomod:Snekproof. Choose 1 of 3 random sneckomod:Offclass cards to add into your hand. It costs 0 this turn. Exhaust. |
| Shift | ![](small-card-images/Shift.png) | ![](small-card-images/ShiftPlus.png) | Uncommon | Skill | 0 | sneckomod:Snekproof. Exhaust all sneckomod:Offclass cards in your hand, replacing them with new ones (that cost 1 less). |
| Slither Strike | ![](small-card-images/SlitherStrike.png) | ![](small-card-images/SlitherStrikePlus.png) | Uncommon | Attack | 1 | Deal 9(12) damage. Reduce the cost of sneckomod:Offclass cards in your hand by 1 this turn. |
| Snake Sap | ![](small-card-images/SnakeSap.png) | ![](small-card-images/SnakeSapPlus.png) | Uncommon | Attack | 1 | sneckomod:Snekproof. Deal !qqq! - 3(4) damage. Gain 1 - 3(4) [E] . Exhaust. |
| Snek Beam | ![](small-card-images/SnekBeam.png) | ![](small-card-images/SnekBeamPlus.png) | Uncommon | Attack | 1 | Deal damage to ALL enemies equal to the number of Unknown cards in your deck. Exhaust. (not Exhaust.) |
| Soul Cleanse | ![](small-card-images/SoulCleanse.png) | ![](small-card-images/SoulCleansePlus.png) | Uncommon | Skill | 0 | sneckomod:Snekproof. sneckomod:Muddle your hand. Cards sneckomod:Muddled this way cannot cost 3. Exhaust. (not Exhaust.) |
| Trash to Treasure | ![](small-card-images/TrashtoTreasure.png) | ![](small-card-images/TrashtoTreasurePlus.png) | Uncommon | Skill | 0 | sneckomod:Snekproof. Exhaust a card. Gain [E] equal to its cost. Exhaust. (not Exhaust.) |
| Unending Supply | ![](small-card-images/UnendingSupply.png) | ![](small-card-images/UnendingSupplyPlus.png) | Uncommon | Power | 1(0) | At the start of each turn, add a random sneckomod:Offclass card to your hand and sneckomod:Muddle it. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Rare | Attack |  | *Unknown (Upgraded) Rare Attack Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Rare | Skill |  | *Unknown (Upgraded) 3 Cost Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Rare | Skill |  | *Unknown (Upgraded) Boss card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Rare | Skill |  | *Unknown (Upgraded) Rare Skill Card. |
| ??? | ![](small-card-images/.png) | ![](small-card-images/Plus.png) | Rare | Power |  | *Unknown (Upgraded) Rare Power Card. |
| Cheat | ![](small-card-images/Cheat.png) | ![](small-card-images/CheatPlus.png) | Rare | Skill | 0 | sneckomod:Snekproof. This turn, cards that choose a random number for their effect choose the maximum possible number. Exhaust. (not Exhaust.) |
| Danger Noodle | ![](small-card-images/DangerNoodle.png) | ![](small-card-images/DangerNoodlePlus.png) | Rare | Attack | 2 | Deal 9(12) damage. Repeat this for each sneckomod:Offclass card in your hand, then Exhaust those cards. |
| Exotic Form | ![](small-card-images/ExoticForm.png) | ![](small-card-images/ExoticFormPlus.png) | Rare | Power | 3(2) | Whenever you play a sneckomod:Offclass card, draw 1 card. |
| Glittering Gambit | ![](small-card-images/GlitteringGambit.png) | ![](small-card-images/GlitteringGambitPlus.png) | Rare | Skill | 0 | sneckomod:Snekproof. Gain -10(0) - 30 *Gold. Exhaust. |
| More Power! | ![](small-card-images/MorePower!.png) | ![](small-card-images/MorePower!Plus.png) | Rare | Power | 1(0) | Obtain an additional Upgraded *Unknown card reward at the end of combat. |
| Mud Shield | ![](small-card-images/MudShield.png) | ![](small-card-images/MudShieldPlus.png) | Rare | Power | 2 | (Innate.)  Whenever you sneckomod:Muddle a card, gain 1 Block next turn. |
| Restock | ![](small-card-images/Restock.png) | ![](small-card-images/RestockPlus.png) | Rare | Skill | 1(0) | sneckomod:Snekproof. Discard your hand. Draw 5-10 cards. Exhaust. |
| Soul Exchange | ![](small-card-images/SoulExchange.png) | ![](small-card-images/SoulExchangePlus.png) | Rare | Skill | 0 | sneckomod:Snekproof. Draw 1 (2) card(s), then Exhaust 1 card. Exhaust your hand, replacing them with random cards of the Exhausted card's class. |
| Transmogrify | ![](small-card-images/Transmogrify.png) | ![](small-card-images/TransmogrifyPlus.png) | Rare | Skill | 1(0) | Lose a random Relic. Choose to gain it back, or obtain a random Relic at the same rarity at the end of combat. Exhaust. |
| Unlimited Rolls | ![](small-card-images/UnlimitedRolls.png) | ![](small-card-images/UnlimitedRollsPlus.png) | Rare | Power | 1 | (Innate.)  At the start of your turn, add a *Soul *Roll to your hand. It gains Ethereal and Exhaust. |
| Defend | ![](small-card-images/Defend.png) | ![](small-card-images/DefendPlus.png) | Basic | Skill | 1 | Gain 5(8) Block. |
| Execute | ![](small-card-images/Execute.png) | ![](small-card-images/ExecutePlus.png) | Basic | Attack | 2 | Deal 6(8) damage !cool! times. champ:Fatigue 10. [fist_icon]   champ:Finisher |
| Strike | ![](small-card-images/Strike.png) | ![](small-card-images/StrikePlus.png) | Basic | Attack | 1 | Deal 6(9) damage. |
| Taunt | ![](small-card-images/Taunt.png) | ![](small-card-images/TauntPlus.png) | Basic | Skill | 1 | [crown_icon] champ:Technique Apply 1 Weak to ALL enemies. Enter (Choose) a random (not random)Stance (to Enter). |
| Adrenal Armor | ![](small-card-images/AdrenalArmor.png) | ![](small-card-images/AdrenalArmorPlus.png) | Common | Skill | 1 | [crown_icon]   champ:Technique Gain 5(7) Block. *Berserker champ:Combo: Play this twice. |
| Backstep | ![](small-card-images/Backstep.png) | ![](small-card-images/BackstepPlus.png) | Common | Skill | 1(0) | Enter champ:Defensive. Gain 6 Block. *Berserker champ:Combo: Gain Block equal to your champ:Fatigue. |
| Berserker's Shout | ![](small-card-images/BerserkersShout.png) | ![](small-card-images/BerserkersShoutPlus.png) | Common | Skill | 1 | [crown_icon] champ:Technique Enter champ:Berserker. champ:Fatigue 5.  (Draw a card.) |
| Bring It On | ![](small-card-images/BringItOn.png) | ![](small-card-images/BringItOnPlus.png) | Common | Skill | 1 | Requires *Defensive or *Berserker. Gain 10(13) Block. Gain 10(13) champ:Counter. [fist_icon]   champ:Finisher |
| Chain Lash | ![](small-card-images/ChainLash.png) | ![](small-card-images/ChainLashPlus.png) | Common | Skill | 1 | [crown_icon]   champ:Technique Repeat this effect 2(3) times. |
| Circumvent | ![](small-card-images/Circumvent.png) | ![](small-card-images/CircumventPlus.png) | Common | Skill | 1 | Gain (4 champ:Counter. Gain) 6 Block. *Defensive champ:Combo: Gain Block equal to your champ:Counter. |
| Crownarang | ![](small-card-images/Crownarang.png) | ![](small-card-images/CrownarangPlus.png) | Common | Attack | 1 | Deal 7(10) damage. If this doesn't cost 0, return it to your hand next turn. It costs 0 until played. |
| Defensive Shout | ![](small-card-images/DefensiveShout.png) | ![](small-card-images/DefensiveShoutPlus.png) | Common | Skill | 1 | [crown_icon] champ:Technique Enter champ:Defensive. Gain 5 champ:Counter.  (Draw a card.) |
| En Garde | ![](small-card-images/EnGarde.png) | ![](small-card-images/EnGardePlus.png) | Common | Skill | 1 | [crown_icon]   champ:Technique Gain 8(11) Block. If your Block is broken this turn, gain 8(11) Block next turn. |
| Fan of Knives | ![](small-card-images/FanofKnives.png) | ![](small-card-images/FanofKnivesPlus.png) | Common | Attack | 1 | Deal 5 damage to ALL enemies. *Berserker champ:Combo: Deals damage twice (three times). Enter champ:Berserker. |
| Flash Strike | ![](small-card-images/FlashStrike.png) | ![](small-card-images/FlashStrikePlus.png) | Common | Attack | 1 | Deal 6(8) damage. *Defensive champ:Combo: Gain 6(8) champ:Counter and 6(8) Block. Enter champ:Defensive. |
| Flurry of Strikes | ![](small-card-images/FlurryofStrikes.png) | ![](small-card-images/FlurryofStrikesPlus.png) | Common | Attack | 1 | Deal 4 damage (. Deal 4 damage) for each card containing "Strike" in your hand. [fist_icon] champ:Finisher |
| Gut Punch | ![](small-card-images/GutPunch.png) | ![](small-card-images/GutPunchPlus.png) | Common | Attack | 1 | Enter champ:Berserker. Deal 5(8) damage. *Defensive champ:Combo: Gain [E] and 5(8) Block. |
| Perfected Strike | ![](small-card-images/PerfectedStrike.png) | ![](small-card-images/PerfectedStrikePlus.png) | Common | Attack | 2 | Deal 14 damage. Deals 2(3) additional damage for ALL your cards containing "Strike". [fist_icon]   champ:Finisher |
| Piledriver | ![](small-card-images/Piledriver.png) | ![](small-card-images/PiledriverPlus.png) | Common | Attack | 2 | Deal 14(18) damage. *Berserker champ:Combo: Apply 2 Vulnerable. *Defensive champ:Combo: Apply 2 Weak. |
| Precise Thrust | ![](small-card-images/PreciseThrust.png) | ![](small-card-images/PreciseThrustPlus.png) | Common | Attack | 1 | Deal 7(9) damage. *Berserker champ:Combo: Deal 7(9) damage. *Defensive champ:Combo: Gain 7(9) Block. |
| Shatter | ![](small-card-images/Shatter.png) | ![](small-card-images/ShatterPlus.png) | Common | Attack | 1 | Deal 8(10) damage. *Berserker champ:Combo: Remove the enemy's Block (and Artifact) before dealing damage. |
| Stance Dance | ![](small-card-images/StanceDance.png) | ![](small-card-images/StanceDancePlus.png) | Common | Skill | 0 | Choose a Stance to Enter. If you were already in that Stance, add (Add) a champ:Combo of that Stance into your hand. |
| Tornado Punch | ![](small-card-images/TornadoPunch.png) | ![](small-card-images/TornadoPunchPlus.png) | Common | Attack | 2 | Deal 10(12) damage to ALL enemies. *Defensive champ:Combo: Gain 5(7) champ:Counter and 5(7) Block for each enemy hit. |
| Arena Preparation | ![](small-card-images/ArenaPreparation.png) | ![](small-card-images/ArenaPreparationPlus.png) | Uncommon | Skill | 0 | [crown_icon]   champ:Technique Add 2(3) random champ:Techniques into your hand. They gain Retain. Exhaust. |
| Battle Plan | ![](small-card-images/BattlePlan.png) | ![](small-card-images/BattlePlanPlus.png) | Uncommon | Skill | 0 | [crown_icon] champ:Technique Draw a card.  (Gain -1(3) Block.) |
| Berserker Style | ![](small-card-images/BerserkerStyle.png) | ![](small-card-images/BerserkerStylePlus.png) | Uncommon | Power | 1 | (Innate.)  Enter champ:Berserker. champ:Berserker champ:Techniques grant 2 more champ:Fatigue. |
| Crooked Strike | ![](small-card-images/CrookedStrike.png) | ![](small-card-images/CrookedStrikePlus.png) | Uncommon | Attack | 1 | Deal 9(12) damage. Hits three times if *Fatigue is 20 or higher. [fist_icon]   champ:Finisher |
| Death Blow | ![](small-card-images/DeathBlow.png) | ![](small-card-images/DeathBlowPlus.png) | Uncommon | Attack | 2 | Deal 10 damage to ALL enemies. champ:Fatigue 10(15). [fist_icon]   champ:Finisher |
| Defensive Style | ![](small-card-images/DefensiveStyle.png) | ![](small-card-images/DefensiveStylePlus.png) | Uncommon | Power | 1 | (Innate.)  Enter champ:Defensive. champ:Defensive *Techniques grant 2 more champ:Counter. |
| Duel | ![](small-card-images/Duel.png) | ![](small-card-images/DuelPlus.png) | Uncommon | Attack | 2 | [crown_icon]   champ:Technique Gain 7(10) Block. Deal 7(10) damage. If there's only one enemy, play this twice. |
| Encircle | ![](small-card-images/Encircle.png) | ![](small-card-images/EncirclePlus.png) | Uncommon | Attack | 1 | Deal 3(5) damage to a random enemy 2 times. *Berserker champ:Combo: Play this twice.  |
| Endless Rage | ![](small-card-images/EndlessRage.png) | ![](small-card-images/EndlessRagePlus.png) | Uncommon | Power | 2(1) | Whenever you lose HP on your turn, gain 1 temporary Strength. |
| Endure | ![](small-card-images/Endure.png) | ![](small-card-images/EndurePlus.png) | Uncommon | Skill | 1 | [crown_icon] champ:Technique Gain 7(10) Block. This card's Block is increased by Strength instead of Dexterity (not instead of Dexterity). |
| Enraged Bash | ![](small-card-images/EnragedBash.png) | ![](small-card-images/EnragedBashPlus.png) | Uncommon | Attack | 1 | Deal 5 damage (1(2) times). champ:Fatigue 5. *Berserker champ:Combo: This card hits an additional time this combat. |
| Face Slap | ![](small-card-images/FaceSlap.png) | ![](small-card-images/FaceSlapPlus.png) | Uncommon | Attack | 1 | Enter champ:Berserker. Deal 9(11) damage, twice if enemy is Vulnerable. *Berserker champ:Combo: Apply 2(3) Vulnerable. |
| False Counter | ![](small-card-images/FalseCounter.png) | ![](small-card-images/FalseCounterPlus.png) | Uncommon | Skill | 1 | Requires champ:Defensive. (Gain 6 champ:Counter.)  The next time champ:Counter activates, lose only half. [fist_icon] champ:Finisher |
| Fancy Footwork | ![](small-card-images/FancyFootwork.png) | ![](small-card-images/FancyFootworkPlus.png) | Uncommon | Skill | 0 | Requires *Defensive or *Berserker. Enter the Stance you aren't in. Draw 1(2) card(s). |
| Finish Him | ![](small-card-images/FinishHim.png) | ![](small-card-images/FinishHimPlus.png) | Uncommon | Attack | 1(0) | Requires champ:Berserker. Deal damage equal to your champ:Fatigue. [fist_icon]   champ:Finisher |
| Focus: Berserker | ![](small-card-images/Focus-Berserker.png) | ![](small-card-images/Focus-BerserkerPlus.png) | Uncommon | Skill | 0 | [crown_icon]   champ:Technique Enter champ:Berserker. If you end this turn with at least 20 champ:Fatigue, deal 10(15) damage to ALL enemies. |
| Focus: Defensive | ![](small-card-images/Focus-Defensive.png) | ![](small-card-images/Focus-DefensivePlus.png) | Uncommon | Skill | 0 | [crown_icon]   champ:Technique Enter champ:Defensive. If you end this turn with at least 20 champ:Counter, gain 10(15) Block. |
| Good Clean Fight | ![](small-card-images/GoodCleanFight.png) | ![](small-card-images/GoodCleanFightPlus.png) | Uncommon | Power | 1 | If you start your turn in no Stance, gain 2(3) temporary Strength and Dexterity. |
| Iron Fortress | ![](small-card-images/IronFortress.png) | ![](small-card-images/IronFortressPlus.png) | Uncommon | Power | 1 | Whenever you enter a Stance, gain 2(3) Block and 2(3) champ:Counter. |
| Lariat | ![](small-card-images/Lariat.png) | ![](small-card-images/LariatPlus.png) | Uncommon | Skill | X | [crown_icon] champ:Technique Perform X times: (times, then gain [E] :) Gain 5 Block. Trigger champ:Technique. |
| Moment of Truth | ![](small-card-images/MomentofTruth.png) | ![](small-card-images/MomentofTruthPlus.png) | Uncommon | Skill | 0 | Retain. (Draw 1 card.)  [fist_icon] champ:Finisher |
| Parry | ![](small-card-images/Parry.png) | ![](small-card-images/ParryPlus.png) | Uncommon | Skill | 2 | Gain 10(16) Counter. If your Counter is used this turn, add *Riposte to your hand. |
| Preemptive Strike | ![](small-card-images/PreemptiveStrike.png) | ![](small-card-images/PreemptiveStrikePlus.png) | Uncommon | Attack | 1(0) | Requires *Defensive. Deal damage equal to your champ:Counter to ALL enemies. Lose half of your champ:Counter. |
| Rapid Strikes | ![](small-card-images/RapidStrikes.png) | ![](small-card-images/RapidStrikesPlus.png) | Uncommon | Attack | 1 | Deal 3 damage 2(3) times. Deal 3 damage an additional time for each champ:Technique used this turn. |
| Reckless Leap | ![](small-card-images/RecklessLeap.png) | ![](small-card-images/RecklessLeapPlus.png) | Uncommon | Attack | 2 | Requires champ:Berserker. Deal 18(20) damage. champ:Fatigue 15(20). |
| Refreshment | ![](small-card-images/Refreshment.png) | ![](small-card-images/RefreshmentPlus.png) | Uncommon | Skill | 1 | *Berserker champ:Combo: Gain [E] [E] ([E]), then Exhaust this. *Defensive champ:Combo: Draw 3(4) cards. |
| Rising Strike | ![](small-card-images/RisingStrike.png) | ![](small-card-images/RisingStrikePlus.png) | Uncommon | Attack | 1 | [crown_icon]   champ:Technique Deal 7(10) damage. Play this twice if the last played card was a champ:Technique. |
| Set A Trap | ![](small-card-images/SetATrap.png) | ![](small-card-images/SetATrapPlus.png) | Uncommon | Skill | 1 | (Gain 6 champ:Counter.)  *Defensive champ:Combo: Gain 6 champ:Counter for each Attack in your hand. Enter champ:Defensive. |
| Shield Wall | ![](small-card-images/ShieldWall.png) | ![](small-card-images/ShieldWallPlus.png) | Uncommon | Power | 2 | Gain 2 Dexterity. At the end of each turn, gain 6(9) champ:Counter. |
| Sigil of Victory | ![](small-card-images/SigilofVictory.png) | ![](small-card-images/SigilofVictoryPlus.png) | Uncommon | Skill | 0 | [crown_icon]   champ:Technique Repeat this effect 2(4) times. Exhaust. |
| Skillful Dodge | ![](small-card-images/SkillfulDodge.png) | ![](small-card-images/SkillfulDodgePlus.png) | Uncommon | Skill | 1 | Gain 4 Block. Gain 4 champ:Counter. *Defensive champ:Combo: Increase this card's Block and champ:Counter by !cool! this combat. |
| Vicious Mockery | ![](small-card-images/ViciousMockery.png) | ![](small-card-images/ViciousMockeryPlus.png) | Uncommon | Skill | 0 | *Berserker champ:Combo: Gain 3(5) temporary Strength. *Defensive champ:Combo: Gain 3(5) temporary  Dexterity. |
| Cheap Shot | ![](small-card-images/CheapShot.png) | ![](small-card-images/CheapShotPlus.png) | Rare | Attack | 2(1) | Deal 5 damage. If the enemy is a Boss, deal damage two more times. If not, stun it. Exhaust. |
| Clobber | ![](small-card-images/Clobber.png) | ![](small-card-images/ClobberPlus.png) | Rare | Attack | 1 | Deal 10(13) damage. *Berserker champ:Combo: Gain [E] . *Defensive champ:Combo: Gain Block equal to unblocked damage dealt. |
| Dancing Master | ![](small-card-images/DancingMaster.png) | ![](small-card-images/DancingMasterPlus.png) | Rare | Power | 1 | The third time you enter a Stance each turn, gain [E] ([E]) and draw 2 cards. |
| Devastate | ![](small-card-images/Devastate.png) | ![](small-card-images/DevastatePlus.png) | Rare | Attack | 5 | Deal 24(32) damage. Costs 1 less [E] for each Finisher played this combat. [fist_icon]   champ:Finisher |
| Enchant Crown | ![](small-card-images/EnchantCrown.png) | ![](small-card-images/EnchantCrownPlus.png) | Rare | Skill | 1(0) | Choose a card in hand. It costs 0 this combat. Exhaust. |
| Enchant Shield | ![](small-card-images/EnchantShield.png) | ![](small-card-images/EnchantShieldPlus.png) | Rare | Skill | 1(0) | Choose a card in hand. Increase its Block by 5 for this combat. Exhaust. |
| Enchant Sword | ![](small-card-images/EnchantSword.png) | ![](small-card-images/EnchantSwordPlus.png) | Rare | Skill | 1(0) | Choose a card in hand. Increase its damage by 5 for this combat. Exhaust. |
| Gladiator Form | ![](small-card-images/GladiatorForm.png) | ![](small-card-images/GladiatorFormPlus.png) | Rare | Power | 3(2) | Whenever you use a champ:Technique *Bonus, draw a card. Whenever you use a champ:Finisher *Bonus, gain [E] next turn. |
| Hold Firm | ![](small-card-images/HoldFirm.png) | ![](small-card-images/HoldFirmPlus.png) | Rare | Skill | 2 | Gain 15(20) Block. Gain 10(15) champ:Counter. Gain 1 bronze:Blur. |
| Ignore Pain | ![](small-card-images/IgnorePain.png) | ![](small-card-images/IgnorePainPlus.png) | Rare | Skill | 3(2) | Your HP cannot be reduced until your next turn. Exhaust. |
| Improvising | ![](small-card-images/Improvising.png) | ![](small-card-images/ImprovisingPlus.png) | Rare | Power | 2(1) | The first time you use a champ:Combo each turn, return it to your hand. It costs 0 until played. |
| Last Stand | ![](small-card-images/LastStand.png) | ![](small-card-images/LastStandPlus.png) | Rare | Power | 1(0) | Can only be played if you're under 50% HP. Remove all debuffs. Gain 6 Strength. [fist_icon]   champ:Finisher |
| Masterful Slash | ![](small-card-images/MasterfulSlash.png) | ![](small-card-images/MasterfulSlashPlus.png) | Rare | Attack | 2 | Deal 10 damage. Deals 1(2) additional damage for ALL your Upgraded cards. |
| Murder Strike | ![](small-card-images/MurderStrike.png) | ![](small-card-images/MurderStrikePlus.png) | Rare | Attack | 8(6) | Retain. Deal 15(21) damage. When you use a champ:Technique, this card costs 1 less and deals 3 more damage. Exhaust. |
| Shield Throw | ![](small-card-images/ShieldThrow.png) | ![](small-card-images/ShieldThrowPlus.png) | Rare | Attack | 1 | Gain 9(13) Block. Deal damage equal to your Block. Unless *Defensive champ:Combo: You can't gain Block next turn. |
| Steel Edge | ![](small-card-images/SteelEdge.png) | ![](small-card-images/SteelEdgePlus.png) | Rare | Attack | X | *Berserker champ:Combo: Deal 9(12) damage X times. *Defensive champ:Combo: Gain 9(12) Block X times. |
| Strike of Genius | ![](small-card-images/StrikeofGenius.png) | ![](small-card-images/StrikeofGeniusPlus.png) | Rare | Power | 2 | At the start of your turn, add a random (Upgraded) card containing "Strike" into (to) your hand. It costs 0 until played and gains Exhaust. |
| Sword Throw | ![](small-card-images/SwordThrow.png) | ![](small-card-images/SwordThrowPlus.png) | Rare | Attack | 1 | Deal 8 damage 2(3) times. Unless *Berserker champ:Combo: You can't attack next turn. |
| Triple Strike | ![](small-card-images/TripleStrike.png) | ![](small-card-images/TripleStrikePlus.png) | Rare | Attack | 2 | [crown_icon] champ:Technique Deal 6(9) damage. Add 2 (Upgraded) *Strikes into your hand. They cost 0 and have champ:Technique. Exhaust. |
| Ultimate Stance | ![](small-card-images/UltimateStance.png) | ![](small-card-images/UltimateStancePlus.png) | Rare | Skill | 1 | [crown_icon] champ:Technique Requires *Defensive or *Berserker. Enter champ:Ultimate Stance for 1 (1(2)) turn(s). |
| Curl Up | ![](small-card-images/CurlUp.png) | ![](small-card-images/CurlUpPlus.png) | Basic | Skill | 1 | Gain 10(13) Block if in guardianmod:Defensive_Mode. Otherwise, guardianmod:Brace 10(13). [ guardianmod:Socket ] |
| Defend | ![](small-card-images/Defend.png) | ![](small-card-images/DefendPlus.png) | Basic | Skill | 1 | Gain 5(8) Block. |
| Strike | ![](small-card-images/Strike.png) | ![](small-card-images/StrikePlus.png) | Basic | Attack | 1 | Deal 6(9) damage. |
| Twin Slam | ![](small-card-images/TwinSlam.png) | ![](small-card-images/TwinSlamPlus.png) | Basic | Attack | 1 | Deal 4(6) damage !GuardianMulti! times. [ guardianmod:Socket ] [ guardianmod:Socket ] |
| Aquamarine | ![](small-card-images/Aquamarine.png) | ![]() | Common | Skill | 0 | guardianmod:Gem. Add a *Crystal *Ward to your hand. |
| Body Slam | ![](small-card-images/BodySlam.png) | ![](small-card-images/BodySlamPlus.png) | Common | Attack | 1(0) | Deal damage equal to your Block. |
| Charge Core | ![](small-card-images/ChargeCore.png) | ![](small-card-images/ChargeCorePlus.png) | Common | Attack | 1 | Deal 10(15) damage, then place this card into guardianmod:Stasis. guardianmod:Tick - Draw a card. guardianmod:Volatile. |
| Crystal Ray | ![](small-card-images/CrystalRay.png) | ![](small-card-images/CrystalRayPlus.png) | Common | Attack | 2 | Deal 10(14) damage. Damage is increased by 2 for each guardianmod:Gem in ALL of your guardianmod:Socketed cards. |
| Emerald | ![](small-card-images/Emerald.png) | ![]() | Common | Skill | 0 | guardianmod:Gem. Gain 1 temporary Dexterity. |
| Incinerate | ![](small-card-images/Incinerate.png) | ![](small-card-images/IncineratePlus.png) | Common | Attack | 1 | Deal 7(10) damage. guardianmod:Accelerate. [ guardianmod:Socket ] |
| Piercing Hide | ![](small-card-images/PiercingHide.png) | ![](small-card-images/PiercingHidePlus.png) | Common | Skill | 1 | Gain 7(9) Block and 2(3) temporary Thorns. guardianmod:Brace 3. [ guardianmod:Socket ] |
| Planning | ![](small-card-images/Planning.png) | ![](small-card-images/PlanningPlus.png) | Common | Skill | 0 | Place the top 2 cards of your draw pile into guardianmod:Stasis. [ guardianmod:Socket ]  ([ guardianmod:Socket ]) |
| Priming Shot | ![](small-card-images/PrimingShot.png) | ![](small-card-images/PrimingShotPlus.png) | Common | Attack | 1 | Deal 8(11) damage. guardianmod:Brace 3(4). [ guardianmod:Socket ] |
| Recover | ![](small-card-images/Recover.png) | ![](small-card-images/RecoverPlus.png) | Common | Skill | 1 | Gain 5(8) Block. guardianmod:Brace 3(4). Place a card from your discard pile into guardianmod:Stasis. |
| Reroute | ![](small-card-images/Reroute.png) | ![](small-card-images/ReroutePlus.png) | Common | Attack | 1 | Deal 9(12) damage. Place the next non-Exhausting Attack or Skill you play this turn into guardianmod:Stasis. [ guardianmod:Socket ] |
| Roll Attack | ![](small-card-images/RollAttack.png) | ![](small-card-images/RollAttackPlus.png) | Common | Attack | 2 | Deal 16(20) damage. If in guardianmod:Defensive_Mode, affects ALL enemies. Otherwise, guardianmod:Brace 8. [ guardianmod:Socket ] |
| Ruby | ![](small-card-images/Ruby.png) | ![]() | Common | Skill | 0 | guardianmod:Gem. Gain 1 temporary Strength. |
| Shield Charger | ![](small-card-images/ShieldCharger.png) | ![](small-card-images/ShieldChargerPlus.png) | Common | Skill | 2 | Place this card into guardianmod:Stasis. guardianmod:Tick - guardianmod:Brace 2, then Gain 8(11) Block and [E]. guardianmod:Volatile. |
| Suspension | ![](small-card-images/Suspension.png) | ![](small-card-images/SuspensionPlus.png) | Common | Skill | 0 | (Draw a card.)  Place a card in your hand into guardianmod:Stasis. [ guardianmod:Socket ] |
| Temporal Shield | ![](small-card-images/TemporalShield.png) | ![](small-card-images/TemporalShieldPlus.png) | Common | Skill | 1 | Gain 8(10) Block. Draw 1(2) card if you have a card in guardianmod:Stasis. |
| Temporal Strike | ![](small-card-images/TemporalStrike.png) | ![](small-card-images/TemporalStrikePlus.png) | Common | Attack | 1 | Deal 5(8) damage. Gain [E] if you have a card in guardianmod:Stasis. [ guardianmod:Socket ] |
| Tourmaline | ![](small-card-images/Tourmaline.png) | ![]() | Common | Skill | 0 | guardianmod:Gem. Gain 1 temporary Thorns. |
| Vent Steam | ![](small-card-images/VentSteam.png) | ![](small-card-images/VentSteamPlus.png) | Common | Skill | 1 | Apply 2(3) Vulnerable. [ guardianmod:Socket ] [ guardianmod:Socket ] |
| Walker Claw | ![](small-card-images/WalkerClaw.png) | ![](small-card-images/WalkerClawPlus.png) | Common | Attack | 2 | Deal 15(18) damage. Strength affects this card 2(3) times. [ guardianmod:Socket ] |
| Amber | ![](small-card-images/Amber.png) | ![]() | Uncommon | Skill | 0 | guardianmod:Gem. guardianmod:Accelerate. |
| Amethyst | ![](small-card-images/Amethyst.png) | ![]() | Uncommon | Skill | 0 | guardianmod:Gem. ALL enemies lose 2 Strength this turn. |
| Ancient Attack | ![](small-card-images/AncientAttack.png) | ![](small-card-images/AncientAttackPlus.png) | Uncommon | Skill | 2 | Gain 1 Strength and 1 Artifact. Add a random Attack card to your hand. (It costs 1 less this combat.) Exhaust. |
| Ancient Power | ![](small-card-images/AncientPower.png) | ![](small-card-images/AncientPowerPlus.png) | Uncommon | Skill | 2 | Gain 1 Dexterity and 1 Artifact. Add a random Power card to your hand. (It costs 1 less this combat.) Exhaust. |
| Armored Protocol | ![](small-card-images/ArmoredProtocol.png) | ![](small-card-images/ArmoredProtocolPlus.png) | Uncommon | Power | 1 | Gain 5(8) Block at the end of each turn while in guardianmod:Defensive_Mode. guardianmod:Brace 10. |
| Bronze Armor | ![](small-card-images/BronzeArmor.png) | ![](small-card-images/BronzeArmorPlus.png) | Uncommon | Skill | 1 | Gain 1(2) Artifact. guardianmod:Brace 10. Exhaust. |
| Charge Up | ![](small-card-images/ChargeUp.png) | ![](small-card-images/ChargeUpPlus.png) | Uncommon | Skill | 0(1) | Place this card into guardianmod:Stasis. guardianmod:Tick - Gain 8 Block and 1 Strength. guardianmod:Volatile. |
| Clone | ![](small-card-images/Clone.png) | ![](small-card-images/ClonePlus.png) | Uncommon | Skill | 1 | Choose a card. Place a copy of that card into guardianmod:Stasis. (guardianmod:Accelerate.)  Exhaust. |
| Emergency | ![](small-card-images/Emergency.png) | ![](small-card-images/EmergencyPlus.png) | Uncommon | Skill | 0 | guardianmod:Accelerate until a card in guardianmod:Stasis returns to your hand. Exhaust. (not Exhaust.) |
| Evasive Protocol | ![](small-card-images/EvasiveProtocol.png) | ![](small-card-images/EvasiveProtocolPlus.png) | Uncommon | Power | 1 | While in guardianmod:Defensive_Mode, raise your Dexterity by 3(5). guardianmod:Brace 10. |
| Floating Orbs | ![](small-card-images/FloatingOrbs.png) | ![](small-card-images/FloatingOrbsPlus.png) | Uncommon | Power | 1(0) | At the start of your turn, add an *Orb *Slam to your hand. |
| Fragmented Gem | ![](small-card-images/FragmentedGem.png) | ![]() | Uncommon | Skill | 0 | guardianmod:Gem. Add a *Crystal *Shiv to your hand. |
| Future Plans | ![](small-card-images/FuturePlans.png) | ![](small-card-images/FuturePlansPlus.png) | Uncommon | Power | 1 | (Innate.)  At the end of your turn, place up to 1 card in your hand in guardianmod:Stasis. |
| Garnet | ![](small-card-images/Garnet.png) | ![]() | Uncommon | Skill | 0 | guardianmod:Gem. Apply 1 Vulnerable to ALL enemies. |
| Guardian Whirl | ![](small-card-images/GuardianWhirl.png) | ![](small-card-images/GuardianWhirlPlus.png) | Uncommon | Attack | 1 | Must be in *Defensive *Mode. Exit *Defensive *Mode. Deal 4 damage 4(5) times to ALL enemies. |
| Harden | ![](small-card-images/Harden.png) | ![](small-card-images/HardenPlus.png) | Uncommon | Skill | 1 | Must be in *Defensive *Mode. Gain 12(16) Block and 2(3) Thorns. |
| Multi-Beam | ![](small-card-images/Multi-Beam.png) | ![](small-card-images/Multi-BeamPlus.png) | Uncommon | Attack | X | Deal 5(7) damage to ALL enemies X times. guardianmod:Tick - Increase this card's damage by 1(2). |
| Orb Support | ![](small-card-images/OrbSupport.png) | ![](small-card-images/OrbSupportPlus.png) | Uncommon | Attack | 0 | Innate. Place a random card from your draw pile into guardianmod:Stasis. Deal 5(7) damage. Gain 5(7) Block. Exhaust. |
| Orbwalk | ![](small-card-images/Orbwalk.png) | ![](small-card-images/OrbwalkPlus.png) | Uncommon | Power | 2 | Gain 2 Strength. guardianmod:Tick - Gain 1 Strength. guardianmod:Volatile. (not guardianmod:Volatile.) |
| Poly Beam | ![](small-card-images/PolyBeam.png) | ![](small-card-images/PolyBeamPlus.png) | Uncommon | Attack | 1 | Deal 2 damage to a random enemy 4(5) times. |
| Preprogram | ![](small-card-images/Preprogram.png) | ![](small-card-images/PreprogramPlus.png) | Uncommon | Skill | 0 | Look at the top 4(7) cards of your draw pile. You may choose one to place into guardianmod:Stasis. [ guardianmod:Socket ] |
| Prismatic Barrier | ![](small-card-images/PrismaticBarrier.png) | ![](small-card-images/PrismaticBarrierPlus.png) | Uncommon | Skill | 1 | Gain 2(4) Block for each guardianmod:Gem in this card. [ guardianmod:Socket ] [ guardianmod:Socket ] [ guardianmod:Socket ] |
| Prismatic Spray | ![](small-card-images/PrismaticSpray.png) | ![](small-card-images/PrismaticSprayPlus.png) | Uncommon | Attack | 1 | Deal 2(4) damage for each guardianmod:Gem in this card. [ guardianmod:Socket ] [ guardianmod:Socket ] [ guardianmod:Socket ] |
| Quartz | ![](small-card-images/Quartz.png) | ![]() | Uncommon | Skill | 0 | guardianmod:Gem. Draw a card. |
| Refracted Beam | ![](small-card-images/RefractedBeam.png) | ![](small-card-images/RefractedBeamPlus1.png) | Uncommon | Attack | 2 | Deal 4 damage 4(5) times. Decrease the number of times this card hits by 1 this combat. Can be upgraded any number of times. |
| Repulsor | ![](small-card-images/Repulsor.png) | ![](small-card-images/RepulsorPlus.png) | Uncommon | Power | 2(1) | When you draw the first Status or Curse card each turn, Exhaust it and draw a card. |
| Sapphire | ![](small-card-images/Sapphire.png) | ![]() | Uncommon | Skill | 0 | guardianmod:Gem. guardianmod:Brace 3. |
| Sentry Blast | ![](small-card-images/SentryBlast.png) | ![](small-card-images/SentryBlastPlus.png) | Uncommon | Attack | 0 | Deal 5(7) damage. Place a *Sentry *Wave (*Wave+) into guardianmod:Stasis. Exhaust. |
| Shield Spikes | ![](small-card-images/ShieldSpikes.png) | ![](small-card-images/ShieldSpikesPlus.png) | Uncommon | Skill | 2 | Gain 12(15) Block. Gain 4(6) temporary Thorns if in guardianmod:Defensive_Mode. Otherwise, guardianmod:Brace 8. |
| Spiker Protocol | ![](small-card-images/SpikerProtocol.png) | ![](small-card-images/SpikerProtocolPlus.png) | Uncommon | Power | 1 | Gain 4(6) Thorns while in guardianmod:Defensive_Mode. guardianmod:Brace 10. |
| Time Bomb | ![](small-card-images/TimeBomb.png) | ![](small-card-images/TimeBombPlus.png) | Uncommon | Skill | 2 | Place this card into guardianmod:Stasis. When this card would leave guardianmod:Stasis, deal 22(30) damage to ALL enemies. guardianmod:Volatile. |
| Time Capacitor | ![](small-card-images/TimeCapacitor.png) | ![](small-card-images/TimeCapacitorPlus.png) | Uncommon | Power | 1 | Gain 2(3) guardianmod:Stasis Slots. |
| Ancient Construct | ![](small-card-images/AncientConstruct.png) | ![](small-card-images/AncientConstructPlus.png) | Rare | Power | 2 | (Gain 1 Artifact.)  At the start of your turn, if you have no Artifact, gain 1 Artifact. |
| Bauble Burst | ![](small-card-images/BaubleBurst.png) | ![](small-card-images/BaubleBurstPlus.png) | Rare | Attack | 2 | Deal 10 damage. Perform the following 2(3) times: [ guardianmod:Socket ] [ guardianmod:Socket ] |
| Citrine | ![](small-card-images/Citrine.png) | ![]() | Rare | Skill | 0 | guardianmod:Gem. Gain [E]. |
| Compile Package | ![](small-card-images/CompilePackage.png) | ![](small-card-images/CompilePackagePlus.png) | Rare | Skill | 0 | Choose one of three guardianmod:Packages to add to your hand. (The cards the guardianmod:Package adds will all be Upgraded.) Exhaust. |
| Construction Form | ![](small-card-images/ConstructionForm.png) | ![](small-card-images/ConstructionFormPlus.png) | Rare | Power | 3 | Ethereal. (not Ethereal.) Gain 2 guardianmod:Buffer. At the start of each turn, if you have guardianmod:Buffer, gain 1 Strength. |
| Exploit Gems | ![](small-card-images/ExploitGems.png) | ![](small-card-images/ExploitGemsPlus.png) | Rare | Skill | 0 | Draw a card. [ guardianmod:Socket ] [ guardianmod:Socket ]  ([ guardianmod:Socket ]) |
| Fierce Bash | ![](small-card-images/FierceBash.png) | ![](small-card-images/FierceBashPlus.png) | Rare | Attack | 3 | Deal 18(28) damage. Place this into guardianmod:Stasis. guardianmod:Tick - Increase this card's damage by 3. |
| Gem Cannon | ![](small-card-images/GemCannon.png) | ![](small-card-images/GemCannonPlus.png) | Rare | Attack | 0 | (Retain.)  Exhaust all guardianmod:Gems and all Socketed cards. Deal 10 damage to a random enemy for each guardianmod:Gem in those cards. Exhaust. |
| Gem Finder | ![](small-card-images/GemFinder.png) | ![](small-card-images/GemFinderPlus.png) | Rare | Power | 1(0) | At the end of combat, you may choose a Common guardianmod:Gem to add to your deck. |
| Hyper Beam | ![](small-card-images/HyperBeam.png) | ![](small-card-images/HyperBeamPlus.png) | Rare | Attack | 3 | Deal 36(40) damage to ALL enemies. Strength affects this card 2(4) times. Skip your next turn. |
| Laser Turret | ![](small-card-images/LaserTurret.png) | ![](small-card-images/LaserTurretPlus.png) | Rare | Attack | 2 | Place this card into guardianmod:Stasis. guardianmod:Tick - Deal 10(14) damage to a random enemy. guardianmod:Volatile. |
| Onyx | ![](small-card-images/Onyx.png) | ![]() | Rare | Skill | 0 | guardianmod:Gem. Gain 1 Artifact. |
| Revenge Protocol | ![](small-card-images/RevengeProtocol.png) | ![](small-card-images/RevengeProtocolPlus.png) | Rare | Power | 1 | While in guardianmod:Defensive_Mode, raise your Strength by 2(3). guardianmod:Brace 10. |
| Speed Boost | ![](small-card-images/SpeedBoost.png) | ![](small-card-images/SpeedBoostPlus.png) | Rare | Skill | 1 | (Retain.)  guardianmod:Accelerate 3 times. |
| Spheric Shield | ![](small-card-images/SphericShield.png) | ![](small-card-images/SphericShieldPlus.png) | Rare | Skill | 2 | Gain 15(20) Block. guardianmod:Brace 20(30). Exhaust. |
| Stasis Engine | ![](small-card-images/StasisEngine.png) | ![](small-card-images/StasisEnginePlus.png) | Rare | Power | 2 | (Innate.)  When you play the 3rd 0-cost card in a single turn, gain [E] and draw a card. |
| Stasis Field | ![](small-card-images/StasisField.png) | ![](small-card-images/StasisFieldPlus.png) | Rare | Skill | 1 | Gain 7(9) Block. Place this card into guardianmod:Stasis. When this leaves Stasis, increase its Block by 3(4) and set its cost back to 1. |
| Stasis Strike | ![](small-card-images/StasisStrike.png) | ![](small-card-images/StasisStrikePlus.png) | Rare | Attack | 1 | Deal 8 damage. Place this card into guardianmod:Stasis. When this leaves Stasis, increase its damage by 3(4) and set its cost back to 1. |
| Time Sifter | ![](small-card-images/TimeSifter.png) | ![](small-card-images/TimeSifterPlus.png) | Rare | Power | 1 | (Innate.)  At the start of your turn, guardianmod:Accelerate. |




## Potions

| Image | Name | Rarity | Description |
| ----- | ---- | ------ | ----------- |
| ![](potions/BrewofSharpness.png) | Brew of Sharpness | Common | Gain 25 Counter. |
| ![](potions/JarofSlime.png) | Jar of Slime | Common | Apply 15 Goop. |
| ![](potions/MachineOil.png) | Machine Oil | Common | Increase all numbers on cards in the Sequence by 1. |
| ![](potions/Molotov.png) | Molotov | Common | Apply 30 Soulburn. |
| ![](potions/PotentiallyPotentPotion.png) | Potentially Potent Potion | Common | Deal 1-40 damage. |
| ![](potions/SpikedEnergyDrink.png) | Spiked Energy Drink | Common | Muddle the 2 highest-cost cards in your hand. Cards Muddled this way cannot cost 3. |
| ![](potions/StrategyPotion.png) | Strategy Potion | Common | Choose 1 of 2 cards which Enter a Stance to add to your hand (one for each Stance). It costs 0 this turn. |
| ![](potions/TemporalPotion.png) | Temporal Potion | Common | Accelerate all cards in Stasis 2 times. |
| ![](potions/AlchyricalElixir.png) | Alchyrical Elixir | Uncommon | Remove all Compile *Error effects from the next Function you create. Reduce its cost to 0 until played. |
| ![](potions/ArmorersTincture.png) | Armorer's Tincture | Uncommon | Gain 4 Block each time you play a card this turn. |
| ![](potions/BottledTechnique.png) | Bottled Technique | Uncommon | Technique 5 times. |
| ![](potions/CombustiveFluid.png) | Combustive Fluid | Uncommon | Force-Ignite the Active Ghostflame 3 times. |
| ![](potions/Ecto-Cooler.png) | Ecto-Cooler | Uncommon | Choose 1 of 3 random Ethereal cards from any class to add to your hand. It costs 0 this turn. |
| ![](potions/ExoticBeverage.png) | Exotic Beverage | Uncommon | Reduce the cost of Offclass cards in your hand by 1. |
| ![](potions/PolishingOil.png) | Polishing Oil | Uncommon | Enter Defensive Mode for 1 round. |
| ![](potions/SlimyElixir.png) | Slimy Elixir | Uncommon | Whenever an effect applies Goop this combat, apply 2 more. |
| ![](potions/VexingDraught.png) | Vexing Draught | Uncommon | Gain 2 Strength and 2 Dexterity. Add two Burn+ Status cards to your draw pile. |
| ![](potions/ArmyinaBottle.png) | Army in a Bottle | Rare | Spawn 3 random Slimes (Normal or Specialist). |
| ![](potions/InfernoPotion.png) | Inferno Potion | Rare | Ignite the Inferno Ghostflame. |
| ![](potions/KiosCleverConcoction.png) | Kio's Clever Concoction | Rare | Until the Sequence is full, choose 1 of 3 random cards to Encode. |
| ![](potions/LiquidLuck.png) | Liquid Luck | Rare | This turn, cards that choose a random number for their effect choose the maximum possible number. |
| ![](potions/Ooze-InfusedDrink.png) | Ooze-Infused Drink | Rare | Add 4 random 0-cost cards to your hand. |
| ![](potions/QuantumElixir.png) | Quantum Elixir | Rare | Gain Stasis slots until you have 3. 3 times, choose 1 of 3 cards to place into Stasis. |
| ![](potions/SubstanceOfQuestionableLegality.png) | Substance Of Questionable Legality | Rare | Enter Ultimate Stance for 1 turns. |





## Relics

| Image | Name | Rarity | Color | Description | Flavor |
| ----- | ---- | ------ | ----- | ----------- | ------ |
| ![](relics/bronze-BronzeCore.png) | Bronze Core | Starter | The_bronze_automaton | The first #yFunction you create each combat costs #b1 less the turn it is created. | Replace once every 50,000 years. |
| ![](relics/Guardian-ModeShifter.png) | Bronze Gear | Starter | Guardian | At the start of your turn, #yBrace 2. | Protection where you need it most. |
| ![](relics/champ-ChampionCrown.png) | Champion's Crown | Starter | The_champ_gray | When you enter a #yStance while not in one, reduce the cost of a random card in your hand by #b1 this turn. | A WINNER IS YOU! |
| ![](relics/Slimebound-AbsorbEndCombat.png) | Heart of Goo | Starter | Slimebound | Whenever you #yslimeboundmod:Consume, heal 1 HP. | I feel so funky. |
| ![](relics/sneckomod-SneckoSoul.png) | Snecko Soul | Starter | Snecko_cyan | You may Identify #yUnknown cards at Rest Sites. | 0...3...2...2...1 |
| ![](relics/hexamod-SpiritBrand.png) | Spirit Brand | Starter | Hexa_ghost_purple | The first time you #yIgnite a Ghostflame each turn, gain #b5 #yBlock. | A bound protector. |
| ![](relics/Guardian-PocketSentry.png) | Arumba's Pocket Sentry | Common |  | At the start of each turn, alternates between: NL Deal #b7 damage to a random enemy. NL Apply #b1 #yWeak to ALL enemies. | Sentry Mode active. Target acquired. No hard feelings. |
| ![](relics/Guardian-DefensiveModeMoreBlock.png) | Baalor's Lordly Plate | Common | Guardian | Whenever you #yguardianmod:Brace, reduce Mode Shift's counter by 1. | One can never have enough armor. |
| ![](relics/sneckomod-BlankCard.png) | Blank Card | Common |  | At the start of each combat, play a copy of a random card from your deck. | Card Mimic. |
| ![](relics/bronze-BronzeIdol.png) | Bronze Idol | Common |  | #yStatus cards may now be played for useful effects. | An ancient, weaponised antivirus - who knows who made it, and why? |
| ![](relics/champ-DefensiveTrainingManual.png) | Defensive Thesis | Common | The_champ_gray | Defensive Stance's #yFinisher #yBonus grants #b8 more #yBlock. | Pro tip: Don't get hit. |
| ![](relics/champ-FightingForDummies.png) | Fighting for Dummies | Common | The_champ_gray | If you end your turn while in no #yStance, gain #b6 #yBlock. | Step 1. Defeat the enemy |
| ![](relics/Slimebound-StickyStick.png) | Gelatinous Cube | Common |  | Whenever you draw a #rCurse or #yStatus card, draw #b1 card. | Hey, it stuck to your body. |
| ![](relics/Slimebound-AggressiveSlimeRelic.png) | Goop Dweller | Common | Slimebound | At the start of combat, #yslimeboundmod:Split into a #yslimeboundmod:Bruiser Slime. | He followed me home. Can I keep it? |
| ![](relics/sneckomod-LoadedDie.png) | Loaded Die | Common | Snecko_cyan | Cards that choose random numbers have +1 minimum. | Cheese-stuffed. |
| ![](relics/Guardian-PickAxe.png) | Pick of Rhapsody | Common | Guardian | You can now #gMine for #b2 #yguardianmod:Gems at Rest Sites (up to #b3 times). | With as many gemstones that litter the Spire, it is hard to imagine anyone so unlucky to have needed this Pick to aid them. |
| ![](relics/bronze-ProtectiveGoggles.png) | Protective Goggles | Common | The_bronze_automaton | If you end your turn with no cards in the #ySequence, gain #b4 #yBlock. | Look closely. |
| ![](relics/hexamod-BolsterEngine.png) | Rod of Bolstering Flame | Common |  | The first time you play a #yPower card each combat, gain #b6 #yBlock and #b1 #yStrength. | Fire shields! Fire strengthens. |
| ![](relics/sneckomod-SneckoCommon.png) | Seal of Approval | Common | Snecko_cyan | Upon pickup, choose #b1 of #b3 #yUnknown Character cards to add to your deck. All future Unknown Character cards found will be of this character. | I'm The Ironclad and this is my favorite Relic in the Spire. -Merchant Advertising Pamphlet |
| ![](relics/bronze-SilverBullet.png) | Silver Bullet | Common | The_bronze_automaton | Start each combat with a #yPiercing #yShot in the #ySequence. | Spirewolves are long gone. |
| ![](relics/hexamod-MatchstickCase.png) | Sneaky Teakwood Match | Common | Hexa_ghost_purple | At the start of the first turn, #yhexamod:Ignite the #yhexamod:Active Ghostflame and #yhexamod:Advance. | Lights on any surface! |
| ![](relics/bronze-CableSpool.png) | Cable Spool | Uncommon | The_bronze_automaton | Add a copy of the first card you play with #yEncode each combat to the Sequence. | Tangled... |
| ![](relics/bronze-DecasWashers.png) | Deca's Washers | Uncommon |  | At the start of each combat, draw #b3 additional cards and add a #yDazed into your draw pile. | It is unclear why Deca collects these. |
| ![](relics/hexamod-InflammatoryLetter.png) | Jar of TOBSCo | Uncommon | Hexa_ghost_purple | Start each combat with #b1 #yhexamod:Intensity. | A little extra heat makes everything better. |
| ![](relics/Slimebound-MaxSlimesRelic.png) | Jeremiah's Banner | Uncommon | Slimebound | At the start of combat, #yslimeboundmod:Split into a #yslimeboundmod:Leeching slime and gain #b1 Slime slot. | You and ooze army. |
| ![](relics/Guardian-StasisCodex.png) | Pilot's Codex | Uncommon | Guardian | If you end your turn with no cards in #yguardianmod:Stasis, choose #b1 of #b3 cards to place into #yguardianmod:Stasis. | Designs and diagrams of the Spire's earliest manually-driven prototypes, by Master Pilot David. |
| ![](relics/hexamod-CandleOfCauterizing.png) | Red Candle | Uncommon |  | Whenever an #yAttack deals unblocked damage, apply #b2 #yhexamod:Soulburn. | Fire BURNS... |
| ![](relics/sneckomod-ConfusingCodex.png) | Ring of the Snek | Uncommon | Snecko_cyan | At the start of combat, apply #b0-2 #yWeak and #yVulnerable to ALL enemies. | Illegible, unreadable, due by Thursday. |
| ![](relics/Slimebound-PreparedRelic.png) | Slime Soup | Uncommon |  | When you enter a Rest Site, begin the next combat with a #yPrepare card that costs #b0. | Tastes awful, but incredibly healthy. |
| ![](relics/champ-SpectersHand.png) | Spectre's Hand | Uncommon | The_champ_gray | Whenever you play a #yTechnique while not in a #yStance, add a #yStrike or #yDefend to your hand. It costs #b0 and has #yExhaust. | Some victories stay with you. |
| ![](relics/sneckomod-SuperSneckoEye.png) | Super Snecko Eye | Uncommon |  | Replaces Snecko Eye. At the start of your turn, draw #b2 additional cards. Start each combat #yConfused. The first time you draw a card that costs #b3 each combat, reduce its cost to #b0. | 0121012 |
| ![](relics/champ-DeflectingBracers.png) | Deflecting Bracers | Rare |  | At the start of your turn, gain #yCounter equal to the amount of Block lost. | If you thought blocking was good then... |
| ![](relics/champ-DuelingGlove.png) | Dueling Glove | Rare |  | After using a single-target Attack, if the target has no #yVulnerable, apply #b1 #yVulnerable. | Count from ten... |
| ![](relics/Guardian-GemstoneGun.png) | Gemstone Gun | Rare |  | Upon pickup, choose #b3 #yguardianmod:Gems. At the start of each combat, gain a card with Retain, Exhaust, and has each chosen Gem socketed. | Bang! Bang! Bang! Hey, I matched three! |
| ![](relics/champ-GladiatorsBookOfMartialProwess.png) | Gladiators Manual | Rare | The_champ_gray | Whenever you play a #yTechnique, a #yCombo, a #yFinisher, and enter a #yStance in the same turn, gain #b1 #yStrength and #yDexterity. | Try everything - something will stick. |
| ![](relics/bronze-Mallet.png) | Mallet | Rare | The_bronze_automaton | At the start of each combat, add #b2 copies of #yFine #yTuning+ to your hand. | That's it! I'm gettin me mallet! |
| ![](relics/Slimebound-PotencyRelic.png) | Ooze Stone | Rare | Slimebound | At the start of combat, #yslimeboundmod:split into a #yslimeboundmod:Mire Slime and gain #b1 #yslimeboundmod:Potency. | It is said to gain power based on your mood. |
| ![](relics/Guardian-SackOfGems.png) | Sack of Gems | Rare | Guardian | Upon pickup, add #b5 random #yguardianmod:Gems to your deck. | Ooh... shiny! |
| ![](relics/champ-SignatureFinisher.png) | Signature Finisher | Rare | The_champ_gray | Upon pickup, choose a #yFinisher. This #yFinisher costs 0 and never causes your #yStance to be exited. | And now, it's time for my ULTIMATE MOVE! |
| ![](relics/hexamod-Sixitude.png) | Six-Point Brand | Rare |  | Whenever you play #b6 cards, deal #b6 damage to a random enemy. | Fire, fire, fire, fire, fire, FIRE! |
| ![](relics/Slimebound-SlimedTailRelic.png) | Slimed Tail | Rare | Slimebound | When you fall below #b50% of your Maximum HP, #yslimeboundmod:Split into a #yslimeboundmod:Guerilla Slime, and the next time you take damage, your leading slime is #yslimeboundmod:Absorbed instead. (works once per combat). | A fake tail to trick enemies during combat, completely covered in slime. |
| ![](relics/Slimebound-SlimedSkullRelic.png) | Slimy Skull | Rare | Slimebound | Whenever you apply #yslimeboundmod:Goop, apply an additional #b1 #yslimeboundmod:Goop. | A Snecko skull in absolutely awful condition. Unclean and slimy, dirt and grime stick to it like glue. |
| ![](relics/sneckomod-CleanMud.png) | Snake-Charmer's Flute | Rare | Snecko_cyan | #ysneckomod:Muddled cards can't cost #b3. | Sssssss... |
| ![](relics/hexamod-SoulOfChaos.png) | Soul of Chaos | Rare | Hexa_ghost_purple | The second Searing Ghostflame becomes a Mayhem Ghostflame. NL Mayhem Ghostflame activates when you end your turn while it is active. NL Ignition: Play the top card of your draw pile. | Mayhem, made manifest. |
| ![](relics/hexamod-SoulConsumer.png) | Thermal Stone | Rare | Hexa_ghost_purple | If #yhexamod:Soulburn detonates, heal #b4 HP at the end of combat. | A fire would liven this thing up! |
| ![](relics/bronze-Timepiece.png) | Timepiece | Rare | The_bronze_automaton | All #yFunctions you #yCompile gain #yRetain. | From his collection of identical clocks. |
| ![](relics/sneckomod-UnknownEgg.png) | Unknown Egg | Rare | Snecko_cyan | #yUnknown cards in card rewards are #yUpgraded. | What will hatch? Pay $1000 to see. |
| ![](relics/RedIOU.png) | Bandit Contract | Special |  | At the start of the #b3rd boss combat, Red Mask Bandits will assist you. | An agreement from the Bandit trio - partially in exchange for a trinket, but mostly in exchange for their lives. |
| ![](relics/RedIOUUpgrade.png) | Bandit Contract+ | Special |  | At the start of the #b3rd boss combat, Red Mask Bandits will assist you. | An agreement from the Bandit trio - partially in exchange for a trinket, but mostly in exchange for their lives. |
| ![](relics/champ-BlackKnightHelmet.png) | Black Knight's Helm | Special | The_champ_gray | The first time you enter each Stance each combat: NL #bDefensive: Gain 2 Dexterity, Lose 1 Strength. NL #rBerserker: Gain 2 Strength, Lose 1 Dexterity. | Only a flesh wound. |
| ![](relics/bronze-BottledCode.png) | Bottled Code | Special | The_bronze_automaton | Upon pickup, choose a card with #yEncode. Start each combat with this card in the #ySequence. | Actually, I have code for that exact thing... |
| ![](relics/BrokenWingStatue.png) | Broken Wing Statue | Special |  | The cultists that worship the Awakened One will be interested in this. | A broken hunk of a once-magnificent statue. |
| ![](relics/CloakOfManyFaces.png) | Coat of Many Faces | Special |  | Upon pickup, gain Cultist Headpiece, Face Of Cleric, N'loth's Hungry Face, Gremlin Visage, and Ssserpent Head. | It was Steve, and Bill, and Ian, and Fred, and John... |
| ![](relics/HeartBlessingGreen.png) | Emerald Heart Blessing | Special |  | Start each combat with #b1 #yDexterity. | The heart is everything. |
| ![](relics/Slimebound-GreedOozeRelic.png) | Greed Ooze | Special | Slimebound | At the start of combat, spawn #yGreed #yOoze. NL At Rest Sites, #yGreed #yOoze will take #b50 of your gold, increasing its damage by #b1. | A friend found in the Spire who hoards gold. |
| ![](relics/GremlinSack.png) | Gremlin Sack | Special |  | Upon pickup, add 6 cards to your deck from the Match Game. | You were no match for the Gremlin and his bodyguard. |
| ![](relics/champ-LiftRelic.png) | Inner Strength | Special | The_champ_gray | Start each combat with #b1 #yStrength. | It's about the gigantic sword in your heart. |
| ![](relics/KnowingSkull.png) | Knowing Skull | Special |  | At the start of each combat, you may Wish for Souls, Success, or a Pick me Up. | Put me down! |
| ![](relics/sneckomod-D8.png) | Mystical Octahedron | Special | Snecko_cyan | Upon pickup, choose a card that selects a random number for its effects. This card always selects its maximum possible number. | It appears weighted toward one side. |
| ![](relics/NeowBlessing_Player.png) | Neow's Blessing | Special |  | Upon pickup, increase your Maximum HP by #b100. NL Increase your Maximum HP by #b100 at the start of each Act. NL Lose all your Potion slots. NL Draw #b1 less card and lose [E] at the start of your turn. | Ease your rage. Be as tough and unyielding as the Spire itself. |
| ![](relics/champ-ChampStancesModRelic.png) | New Challenger | Special |  | Start each combat in a random Champ #yStance. | Can you take the crown? |
| ![](relics/Guardian-StasisEgg.png) | Quantum Chamber | Special | Guardian | Upon pickup, choose a card. Start each combat with this card removed from your deck. At the start of your #b4th turn, return it and #b2 copies of it to your hand. | You get the chicken by hatching the egg, not by smashing it. |
| ![](relics/HeartBlessingRed.png) | Ruby Heart Blessing | Special |  | Start each combat with #b1 #yStrength. | The heart is strong. The heart is pleased. |
| ![](relics/HeartBlessingBlue.png) | Sapphire Heart Blessing | Special |  | Upon pickup, raise your Max HP by #b10. | The heart is pleased. |
| ![](relics/Slimebound-ScrapOozeRelic.png) | Scrap Ooze | Special | Slimebound | At the start of combat, spawn #yScrap #yOoze. NL At Rest Sites, you can donate a card to the Scrap Ooze, modifying it's damage: NL #b+1 damage for #gUncommons NL #b+2 damage for #yRares NL #b-1 damage for Commons NL #b-2 damage for #rCurses |  |
| ![](relics/ShatteredFragment.png) | Sharpened Fragment | Special |  | At the start of each turn, add a Crystal Shiv to your hand. | Once a broken statue - now a makeshift weapon. |
| ![](relics/TeleportStone.png) | Teleport Stone | Special |  | You may skip any number of rooms the next time you move, but cannot move into a Boss Room. | Never leave home without it. |
| ![](relics/hexamod-TheBrokenSeal.png) | The Broken Seal | Special | Hexa_ghost_purple | Upon pickup, heal all of your HP, then raise your Max HP by #b10. Start each combat with #b2 #yStrength, #b2 #yDexterity, and #b2 #yhexamod:Intensity. | Unlimited, unrestrained, unquenchable power. |
| ![](relics/HeartsMalice.png) | The Heart's Malice | Special |  | Enemies in your first #b3 combats will flee in terror. | The malice of corruption bestowed by the Heart. |
| ![](relics/GremlinWheel.png) | Wheel of Change | Special |  | At each Rest Site, you may spin the wheel once. Choosing to collect its reward uses up this relic. | No one gets two spins, he says. |
| ![](relics/sneckomod-BabySnecko.png) | Young Snecko | Special |  | Deals #b5 damage to a random enemy at the start of your turn. | Bewilderingly adorable. |
| ![](relics/Slimebound-AbsorbEndCombatUpgraded.png) | Black Heart of Goo | Boss | Slimebound | Replaces [#40c840ff]Heart[] [#40c840ff]of[] [#40c840ff]Goo[][#40c840ff].[] NL Whenever you #yslimeboundmod:Consume, heal 2 HP. | The Secret of the Ooze. |
| ![](relics/bronze-ElectromagneticCoil.png) | Electromagnetic Coil | Boss | The_bronze_automaton | #yFunctions are now made up of #b4 cards. | An inefficient but entertaining power source. |
| ![](relics/Guardian-ModeShifterPlus.png) | Guardian Gear | Boss | Guardian | Replaces #rMode #rShifter. NL Begin each combat in #yguardianmod:Defensive_Mode, which persists for #b3 turns. | Replace every 3,000 floors. |
| ![](relics/sneckomod-SneckoTalon.png) | Idol of Retromation | Boss |  | At the start of your turn, reduce the cost of the most expensive card in your hand by #b1 for this turn. | Often called the Idol of Reto for short. |
| ![](relics/sneckomod-SneckoBoss.png) | Lucky Horseshoe | Boss | Snecko_cyan | Upon pickup, choose #b1 of #b3 #yUnknown Character cards. Add #b5 copies of it to your deck. All combats drop an additional card reward of the chosen character's cards. | Make your own luck. |
| ![](relics/bronze-MakeshiftBattery.png) | Makeshift Battery | Boss |  | Gain [E] and add a random #yStatus card into your discard pile at the start of your turn. | It's an 8.99 volt. |
| ![](relics/hexamod-UnbrokenSoul.png) | Mark of the Ether | Boss | Hexa_ghost_purple | Replaces [#723e6dff]Spirit[] [#723e6dff]Brand[][#723e6dff].[] NL The first time you #yIgnite a Ghostflame each turn, gain [E] . | Let’s see if we can do... better. |
| ![](relics/bronze-PlatinumCore.png) | Platinum Core | Boss | The_bronze_automaton | Replaces [#d6ca9eff]Bronze[] [#d6ca9eff]Core[][#d6ca9eff].[] NL The first #b3 #yFunctions you create each combat cost #b1 less the turn they are created. | Changelog: Improved user experience. |
| ![](relics/champ-PowerArmor.png) | Power Armor | Boss | The_champ_gray | At the start of your turn, gain [E] . NL Your maximum #yFatigue and #yCounter is #b20. | Bought used. |
| ![](relics/sneckomod-SuperSneckoSoul.png) | Super Snecko Soul | Boss | Snecko_cyan | Replaces [#407b93ff]Snecko[] [#407b93ff]Soul[][#407b93ff].[] NL Using Identify at Rest Sites is now a Free Action. | 3120231321230320 |
| ![](relics/Slimebound-TarBlob.png) | Tarr Blob | Boss | Slimebound | Gain [E] at the start of your turn. At the start of combat, lose #b1 Slime slot. | The bad kind of Slime. |
| ![](relics/expansioncontent-StudyCardRelic.png) | Tiny Bowler Hat | Boss |  | At the start of combat, add a Study the Spire card to your hand. It costs 0. | Whosoever controls the hat, controls the Spire. |
| ![](relics/champ-ChampionCrownUpgraded.png) | Victorious Crown | Boss | The_champ_gray | Replaces #rChampion's #rCrown. NL Start each combat in #yUltimate #yStance, which lasts for #b2 turns. | Conglaturation!! You are the greatest winner. |
| ![](relics/Guardian-StasisSlotReductionRelic.png) | Wander Bots | Boss | Guardian | On pickup, lose #b2 #yguardianmod:Stasis slots. NL Gain [E] at the start of your turn. | These drones find the most wonderful salvage, but require processing power to maintain. |
| ![](relics/hexamod-IceCube.png) | Xanatos's Icy Charm | Boss | Hexa_ghost_purple | Gain [E] at the start of your turn. #yhexamod:Soulburn takes #b4 turns to activate. | I feel... cold. |
| ![](relics/champ-Barbells.png) | Barbell | Shop |  | Whenever you enter a Rest Site, if you have at least #b10 non-Upgraded cards in your deck, #yUpgrade one at random. | 1000 reps? Psh. I can do 1001. |
| ![](relics/champ-BerserkersGuideToSlaughter.png) | Berserker's Guide | Shop | The_champ_gray | Prevent the first #b10 HP you lose on your turn each combat. | The text is illegible. |
| ![](relics/Guardian-BottledAnomaly.png) | Bottled Anomaly | Shop |  | Upon pickup, choose a card. At the start of each combat, remove it from your draw pile. At the start of turn #b3, add it into your hand. It costs #b0. | Swirling and swirling and finally breaking. |
| ![](relics/Guardian-BottledStasis.png) | Bottled Black Hole | Shop | Guardian | Upon pickup, choose a card. Start each combat with this card in #yguardianmod:Stasis. | Somewhere, something incredible is waiting to be known. |
| ![](relics/Guardian-StasisUpgradeRelic.png) | Cryo Chamber | Shop | Guardian | Gain #b1 #yguardianmod:Stasis slot. When a card enters #yguardianmod:Stasis, #yUpgrade it. | Things always seem better coming out than they did going in. |
| ![](relics/bronze-DonusWashers.png) | Donu's Washers | Shop |  | At the start of combat, gain [E] [E] and add #b1 #yVoid into your draw pile. | It is rather clear why Donu collects these. |
| ![](relics/hexamod-JarOfFuel.png) | Olexa's Shield | Shop | Hexa_ghost_purple | Swap the positions of the Bolstering Ghostflame and the first Searing Ghostflame. | Protection on-demand. |
| ![](relics/Slimebound-SelfDamagePreventRelic.png) | Protective Gear | Shop | Slimebound | Reduce the damage you take from #yslimeboundmod:Tackle cards by #b3. | The best defense is a good offense. |
| ![](relics/sneckomod-RareBoosterPack.png) | Rare Booster Box | Shop | Snecko_cyan | Upon pickup, obtain a #yUnknown #yRare card of each card type. | Mint condition. |
| ![](relics/hexamod-RecyclingMachine.png) | Recycler | Shop | Hexa_ghost_purple | The first time an #yEthereal card is #yExhausted each combat, add a copy to your hand that costs #b0 until played. | One day, it shall be recycled too. |
| ![](relics/sneckomod-SleevedAce.png) | Sleeved Ace | Shop | Snecko_cyan | At the start of each combat, add a #yCheat into your hand with #yRetain. | We're all aces. |




| Image | Name |
| ----- | ---- |
| ![](creatures/GuardianCharacter.png) | The Guardian |
| ![](creatures/SlimeboundCharacter.png) | The Slime Boss |
| ![](creatures/AutomatonChar.png) | the Automaton |
| ![](creatures/ChampChar.png) | the Champ |
| ![](creatures/TheHexaghost.png) | the Hexaghost |
| ![](creatures/TheSnecko.png) | the Snecko |
| ![](creatures/Augmenter.png) | Augmenter |
| ![](creatures/BlackKnight.png) | Black Knight |
| ![](creatures/FaceTrader.png) | Face Trader |
| ![](creatures/ForgetfulTotem.png) | Forgetful Head |
| ![](creatures/ChangingTotem.png) | Head of Change |
| ![](creatures/GrowingTotem.png) | Head of Growth |
| ![](creatures/LooterAlt.png) | Looter |
| ![](creatures/MuggerAlt.png) | Looter |
| ![](creatures/FleeingMerchant.png) | Merchant |
| ![](creatures/CharBossMerchant.png) | Merchant |
| ![](creatures/NeowBoss.png) | Neow |
| ![](creatures/NeowBossFinal.png) | Neow |
| ![](creatures/Defect.png) | The Defect |
| ![](creatures/Ironclad.png) | The Ironclad |
| ![](creatures/Silent.png) | The Silent |
| ![](creatures/Watcher.png) | The Watcher |
| ![](creatures/LadyInBlue.png) | The Woman in Blue |

