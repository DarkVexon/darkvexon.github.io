| Image | Name | Rarity | Description |
| ----- | ---- | ------ | ----------- |
| ![](potions/BrewofSharpness.png) | Brew of Sharpness | Common | Gain 25 Counter. |
| ![](potions/JarofSlime.png) | Jar of Slime | Common | Apply 15 Goop. |
| ![](potions/MachineOil.png) | Machine Oil | Common | Increase all numbers on cards in the Sequence by 1. |
| ![](potions/Molotov.png) | Molotov | Common | Apply 30 Soulburn. |
| ![](potions/PotentiallyPotentPotion.png) | Potentially Potent Potion | Common | Deal 1-40 damage. |
| ![](potions/SpikedEnergyDrink.png) | Spiked Energy Drink | Common | Muddle the 2 highest-cost cards in your hand. Cards Muddled this way cannot cost 3. |
| ![](potions/StrategyPotion.png) | Strategy Potion | Common | Choose 1 of 2 cards which Enter a Stance to add to your hand (one for each Stance). It costs 0 this turn. |
| ![](potions/TemporalPotion.png) | Temporal Potion | Common | Accelerate all cards in Stasis 2 times. |
| ![](potions/AlchyricalElixir.png) | Alchyrical Elixir | Uncommon | Remove all Compile *Error effects from the next Function you create. Reduce its cost to 0 until played. |
| ![](potions/ArmorersTincture.png) | Armorer's Tincture | Uncommon | Gain 4 Block each time you play a card this turn. |
| ![](potions/BottledTechnique.png) | Bottled Technique | Uncommon | Technique 5 times. |
| ![](potions/CombustiveFluid.png) | Combustive Fluid | Uncommon | Force-Ignite the Active Ghostflame 3 times. |
| ![](potions/Ecto-Cooler.png) | Ecto-Cooler | Uncommon | Choose 1 of 3 random Ethereal cards from any class to add to your hand. It costs 0 this turn. |
| ![](potions/ExoticBeverage.png) | Exotic Beverage | Uncommon | Reduce the cost of Offclass cards in your hand by 1. |
| ![](potions/PolishingOil.png) | Polishing Oil | Uncommon | Enter Defensive Mode for 1 round. |
| ![](potions/SlimyElixir.png) | Slimy Elixir | Uncommon | Whenever an effect applies Goop this combat, apply 2 more. |
| ![](potions/VexingDraught.png) | Vexing Draught | Uncommon | Gain 2 Strength and 2 Dexterity. Add two Burn+ Status cards to your draw pile. |
| ![](potions/ArmyinaBottle.png) | Army in a Bottle | Rare | Spawn 3 random Slimes (Normal or Specialist). |
| ![](potions/InfernoPotion.png) | Inferno Potion | Rare | Ignite the Inferno Ghostflame. |
| ![](potions/KiosCleverConcoction.png) | Kio's Clever Concoction | Rare | Until the Sequence is full, choose 1 of 3 random cards to Encode. |
| ![](potions/LiquidLuck.png) | Liquid Luck | Rare | This turn, cards that choose a random number for their effect choose the maximum possible number. |
| ![](potions/Ooze-InfusedDrink.png) | Ooze-Infused Drink | Rare | Add 4 random 0-cost cards to your hand. |
| ![](potions/QuantumElixir.png) | Quantum Elixir | Rare | Gain Stasis slots until you have 3. 3 times, choose 1 of 3 cards to place into Stasis. |
| ![](potions/SubstanceOfQuestionableLegality.png) | Substance Of Questionable Legality | Rare | Enter Ultimate Stance for 1 turns. |

